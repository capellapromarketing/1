import { DateTime } from 'luxon';
import { RRule } from 'rrule';

export type CalendarViewType = 'month' | 'week' | 'day' | 'agenda';

export type RecurrenceFrequency = 'daily' | 'weekly' | 'monthly';

export type RecurrenceEditMode = 'single' | 'thisAndFollowing';

export type VideoCallProvider = 'zoom' | 'meet' | 'teams';

export type TravelTimeOption = 15 | 30 | 60;

export interface CalendarColor {
  id: string;
  name: string;
  hex: string;
  tailwindClass: string;
}

export const CALENDAR_COLORS: CalendarColor[] = [
  { id: 'blue', name: 'Blue', hex: '#007AFF', tailwindClass: 'bg-blue-500' },
  { id: 'green', name: 'Green', hex: '#34C759', tailwindClass: 'bg-green-500' },
  { id: 'purple', name: 'Purple', hex: '#AF52DE', tailwindClass: 'bg-purple-500' },
  { id: 'orange', name: 'Orange', hex: '#FF9500', tailwindClass: 'bg-orange-500' },
  { id: 'red', name: 'Red', hex: '#FF3B30', tailwindClass: 'bg-red-500' },
  { id: 'yellow', name: 'Yellow', hex: '#FFCC00', tailwindClass: 'bg-yellow-500' },
  { id: 'cyan', name: 'Cyan', hex: '#5AC8FA', tailwindClass: 'bg-cyan-500' },
  { id: 'gray', name: 'Gray', hex: '#8E8E93', tailwindClass: 'bg-gray-500' },
];

export interface Calendar {
  id: string;
  name: string;
  color: string;
  isVisible: boolean;
  isDefault?: boolean;
}

export interface RecurrenceRule {
  frequency: RecurrenceFrequency;
  interval: number;
  until?: string;
  count?: number;
  byDay?: number[];
}

export interface VideoCallInfo {
  provider: VideoCallProvider;
  link: string;
}

export interface TravelTime {
  minutes: TravelTimeOption;
  location?: string;
}

export interface CalendarEvent {
  id: string;
  title: string;
  description?: string;
  startTime: string;
  endTime: string;
  timezone: string;
  isAllDay: boolean;
  calendarId: string;
  recurrence?: RecurrenceRule;
  recurrenceId?: string;
  isRecurrenceException?: boolean;
  videoCall?: VideoCallInfo;
  travelTime?: TravelTime;
  location?: string;
  attendees?: string[];
}

export interface Task {
  id: string;
  title: string;
  description?: string;
  dueDate?: string;
  isCompleted: boolean;
  calendarId: string;
  priority?: 'low' | 'medium' | 'high';
}

export interface ParsedEvent {
  title: string;
  startTime?: string;
  endTime?: string;
  date?: string;
  duration?: number;
  location?: string;
  attendees?: string[];
  isAllDay?: boolean;
  confidence: number;
}

export interface SuggestedEvent {
  id: string;
  title: string;
  startTime: string;
  endTime: string;
  reason: string;
  priority: 'high' | 'medium' | 'low';
}

export interface SuggestedBlock {
  id: string;
  type: 'focus' | 'break' | 'buffer';
  startTime: string;
  endTime: string;
  label: string;
}

export interface Priority {
  id: string;
  title: string;
  description: string;
  timeEstimate: number;
}

export interface DailyPlan {
  date: string;
  suggestedEvents: SuggestedEvent[];
  suggestedBlocks: SuggestedBlock[];
  priorities: Priority[];
  summary: string;
}

export interface DragEventData {
  eventId: string;
  type: 'event' | 'task';
  originalStart: string;
  originalEnd: string;
}

export interface TimeSlot {
  hour: number;
  minute: number;
  label: string;
}

export interface CalendarState {
  currentDate: DateTime;
  currentView: CalendarViewType;
  selectedDate: DateTime | null;
  selectedEvent: CalendarEvent | null;
  calendars: Calendar[];
  events: CalendarEvent[];
  tasks: Task[];
  isCreateModalOpen: boolean;
  isEventPopoverOpen: boolean;
  isAIPanelOpen: boolean;
  isAIConsentModalOpen: boolean;
  isSidebarOpen: boolean;
  userTimezone: string;
  nlInputValue: string;
  parsedEvent: ParsedEvent | null;
  dailyPlan: DailyPlan | null;
  isDragging: boolean;
  draggedEventId: string | null;
  undoStack: CalendarEvent[];
}

export interface CalendarActions {
  setCurrentDate: (date: DateTime) => void;
  setCurrentView: (view: CalendarViewType) => void;
  setSelectedDate: (date: DateTime | null) => void;
  setSelectedEvent: (event: CalendarEvent | null) => void;
  toggleCalendarVisibility: (calendarId: string) => void;
  addEvent: (event: CalendarEvent) => void;
  updateEvent: (eventId: string, updates: Partial<CalendarEvent>) => void;
  deleteEvent: (eventId: string) => void;
  addTask: (task: Task) => void;
  updateTask: (taskId: string, updates: Partial<Task>) => void;
  deleteTask: (taskId: string) => void;
  toggleTaskComplete: (taskId: string) => void;
  setIsCreateModalOpen: (isOpen: boolean) => void;
  setIsEventPopoverOpen: (isOpen: boolean) => void;
  setIsAIPanelOpen: (isOpen: boolean) => void;
  setIsAIConsentModalOpen: (isOpen: boolean) => void;
  setIsSidebarOpen: (isOpen: boolean) => void;
  setNLInputValue: (value: string) => void;
  setParsedEvent: (event: ParsedEvent | null) => void;
  setDailyPlan: (plan: DailyPlan | null) => void;
  setIsDragging: (isDragging: boolean) => void;
  setDraggedEventId: (eventId: string | null) => void;
  pushToUndoStack: (event: CalendarEvent) => void;
  popFromUndoStack: () => CalendarEvent | undefined;
  goToToday: () => void;
  goToPrevious: () => void;
  goToNext: () => void;
  moveEventToDate: (eventId: string, newStart: DateTime, newEnd: DateTime) => void;
  convertTaskToEvent: (taskId: string, startTime: DateTime, endTime: DateTime) => void;
}

export type CalendarStore = CalendarState & CalendarActions;
