import { useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { DateTime } from 'luxon';
import { Calendar, Clock, MapPin, Video, RefreshCw, Plane } from 'lucide-react';
import { useCalendarStore } from '../store/calendarStore';
import { useCalendarData } from '../hooks/useCalendarData';
import { 
  getRelativeDateLabel, 
  isToday,
  parseEventDateTime,
  convertToUserTimezone,
  isDifferentTimezone,
  formatTimezoneOffset
} from '../lib/dateUtils';
import { isRecurringEvent, getRecurrenceDescription } from '../lib/recurrence';
import { CALENDAR_COLORS, type CalendarEvent } from '../types/calendar.types';

interface EventGroupProps {
  date: DateTime;
  events: CalendarEvent[];
}

function EventGroup({ date, events }: EventGroupProps) {
  const isTodayDate = isToday(date);
  const dateKey = date.toISODate() || '';

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="mb-6"
      data-testid={`agenda-date-group-${dateKey}`}
    >
      <div
        className={`
          sticky top-0 z-10 flex items-center gap-3 px-4 py-2 
          ${isTodayDate ? 'bg-primary/5' : 'bg-muted/50'}
          border-b
        `}
      >
        <div
          className={`
            w-10 h-10 rounded-full flex items-center justify-center text-lg font-bold
            ${isTodayDate ? 'bg-primary text-primary-foreground' : 'bg-muted'}
          `}
        >
          {date.day}
        </div>
        <div>
          <div className="font-semibold">{getRelativeDateLabel(date)}</div>
          <div className="text-sm text-muted-foreground">
            {date.toFormat('EEEE, MMMM d, yyyy')}
          </div>
        </div>
      </div>

      <div className="divide-y">
        {events.map((event) => (
          <AgendaEventRow key={event.id} event={event} />
        ))}
      </div>
    </motion.div>
  );
}

interface AgendaEventRowProps {
  event: CalendarEvent;
}

function AgendaEventRow({ event }: AgendaEventRowProps) {
  const { userTimezone, calendars, setSelectedEvent } = useCalendarStore();
  
  const calendar = useMemo(() => 
    calendars.find((c) => c.id === event.calendarId),
    [calendars, event.calendarId]
  );

  const calendarColor = useMemo(() => {
    const color = CALENDAR_COLORS.find((c) => c.id === calendar?.color);
    return color?.hex || '#8E8E93';
  }, [calendar]);

  const { start, end } = useMemo(() => parseEventDateTime(event), [event]);
  const localStart = useMemo(() => convertToUserTimezone(start, userTimezone), [start, userTimezone]);
  const localEnd = useMemo(() => convertToUserTimezone(end, userTimezone), [end, userTimezone]);
  const isFromDifferentTimezone = useMemo(() => isDifferentTimezone(event.timezone, userTimezone), [event.timezone, userTimezone]);
  const isRecurring = isRecurringEvent(event);

  const handleClick = () => {
    setSelectedEvent(event);
  };

  return (
    <motion.div
      whileHover={{ backgroundColor: 'hsl(var(--muted) / 0.3)' }}
      className="flex gap-4 px-4 py-3 cursor-pointer"
      onClick={handleClick}
      data-testid={`agenda-event-${event.id}`}
    >
      <div className="flex flex-col items-center w-16 flex-shrink-0 pt-1">
        {event.isAllDay ? (
          <span className="text-sm font-medium text-muted-foreground">All day</span>
        ) : (
          <>
            <span className="text-sm font-semibold">{localStart.toFormat('h:mm')}</span>
            <span className="text-xs text-muted-foreground">{localStart.toFormat('a')}</span>
          </>
        )}
      </div>

      <div
        className="w-1 rounded-full flex-shrink-0"
        style={{ backgroundColor: calendarColor }}
      />

      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-medium truncate">{event.title}</h3>
          <div className="flex items-center gap-1 flex-shrink-0">
            {event.videoCall && (
              <Video className="h-4 w-4 text-primary" />
            )}
            {isRecurring && (
              <RefreshCw className="h-4 w-4 text-muted-foreground" />
            )}
            {event.travelTime && (
              <Plane className="h-4 w-4 text-muted-foreground" />
            )}
          </div>
        </div>

        {event.description && (
          <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
            {event.description}
          </p>
        )}

        <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2 text-xs text-muted-foreground">
          {!event.isAllDay && (
            <div className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              <span>
                {localStart.toFormat('h:mm a')} - {localEnd.toFormat('h:mm a')}
              </span>
            </div>
          )}

          {event.location && (
            <div className="flex items-center gap-1">
              <MapPin className="h-3 w-3" />
              <span className="truncate max-w-[200px]">{event.location}</span>
            </div>
          )}

          {event.videoCall && (
            <a
              href={event.videoCall.link}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 text-primary hover:underline"
              onClick={(e) => e.stopPropagation()}
            >
              <Video className="h-3 w-3" />
              <span>Join {event.videoCall.provider}</span>
            </a>
          )}

          {isFromDifferentTimezone && (
            <div className="flex items-center gap-1 text-orange-500">
              <Calendar className="h-3 w-3" />
              <span>{formatTimezoneOffset(event.timezone)}</span>
            </div>
          )}

          {event.recurrence && (
            <div className="flex items-center gap-1">
              <RefreshCw className="h-3 w-3" />
              <span>{getRecurrenceDescription(event.recurrence)}</span>
            </div>
          )}

          {event.travelTime && (
            <div className="flex items-center gap-1">
              <Plane className="h-3 w-3" />
              <span>{event.travelTime.minutes} min travel</span>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}

export function AgendaView() {
  const { currentDate, userTimezone } = useCalendarStore();
  const { events, isLoading } = useCalendarData();

  const groupedEvents = useMemo(() => {
    const groups = new Map<string, { date: DateTime; events: CalendarEvent[] }>();
    
    const endDate = currentDate.plus({ weeks: 2 });
    let iterDate = currentDate.startOf('day');

    while (iterDate <= endDate) {
      const dateKey = iterDate.toISODate();
      if (dateKey) {
        groups.set(dateKey, { date: iterDate, events: [] });
      }
      iterDate = iterDate.plus({ days: 1 });
    }

    events.forEach((event) => {
      const eventStart = DateTime.fromISO(event.startTime);
      const dateKey = eventStart.toISODate();
      if (dateKey && groups.has(dateKey)) {
        groups.get(dateKey)!.events.push(event);
      }
    });

    groups.forEach((group) => {
      group.events.sort((a, b) => {
        if (a.isAllDay && !b.isAllDay) return -1;
        if (!a.isAllDay && b.isAllDay) return 1;
        return DateTime.fromISO(a.startTime).toMillis() - DateTime.fromISO(b.startTime).toMillis();
      });
    });

    return Array.from(groups.values()).filter((g) => g.events.length > 0);
  }, [events, currentDate, userTimezone]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="h-8 w-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (groupedEvents.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center p-8" data-testid="agenda-empty">
        <Calendar className="h-12 w-12 text-muted-foreground mb-4" />
        <h3 className="text-lg font-semibold mb-2">No upcoming events</h3>
        <p className="text-muted-foreground max-w-md">
          You have no events scheduled for the next two weeks. Create a new event to get started.
        </p>
      </div>
    );
  }

  return (
    <div className="h-full overflow-auto" data-testid="agenda-view">
      <AnimatePresence>
        {groupedEvents.map((group) => (
          <EventGroup
            key={group.date.toISODate()}
            date={group.date}
            events={group.events}
          />
        ))}
      </AnimatePresence>
    </div>
  );
}
