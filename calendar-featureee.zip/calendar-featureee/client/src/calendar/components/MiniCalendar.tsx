import { useMemo } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { DateTime } from 'luxon';
import { Button } from '@/components/ui/button';
import { useCalendarStore } from '../store/calendarStore';
import { getMonthDays, isToday, isCurrentMonth } from '../lib/dateUtils';

const WEEKDAY_LABELS = ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'];

interface MiniCalendarProps {
  selectedDate?: DateTime;
  onDateSelect?: (date: DateTime) => void;
}

export function MiniCalendar({ selectedDate, onDateSelect }: MiniCalendarProps) {
  const { currentDate, setCurrentDate, setSelectedDate, events } = useCalendarStore();

  const [displayMonth, setDisplayMonth] = useMemo(() => {
    return [currentDate, setCurrentDate];
  }, [currentDate, setCurrentDate]);

  const monthDays = useMemo(() => getMonthDays(displayMonth), [displayMonth]);

  const eventsPerDay = useMemo(() => {
    const map = new Map<string, number>();
    events.forEach((event) => {
      const dateKey = DateTime.fromISO(event.startTime).toISODate();
      if (dateKey) {
        map.set(dateKey, (map.get(dateKey) || 0) + 1);
      }
    });
    return map;
  }, [events]);

  const handlePrevMonth = () => {
    setDisplayMonth(displayMonth.minus({ months: 1 }));
  };

  const handleNextMonth = () => {
    setDisplayMonth(displayMonth.plus({ months: 1 }));
  };

  const handleDateClick = (date: DateTime) => {
    setSelectedDate(date);
    onDateSelect?.(date);
  };

  return (
    <div className="p-3" data-testid="mini-calendar">
      <div className="flex items-center justify-between mb-3">
        <span className="text-sm font-semibold" data-testid="text-mini-calendar-month">
          {displayMonth.toFormat('MMMM yyyy')}
        </span>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={handlePrevMonth}
            aria-label="Previous month"
            data-testid="button-mini-prev"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={handleNextMonth}
            aria-label="Next month"
            data-testid="button-mini-next"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-0.5">
        {WEEKDAY_LABELS.map((day) => (
          <div
            key={day}
            className="h-7 flex items-center justify-center text-xs text-muted-foreground font-medium"
          >
            {day}
          </div>
        ))}

        {monthDays.map((day, index) => {
          const isSelected = selectedDate?.hasSame(day, 'day');
          const isTodayDate = isToday(day);
          const isInCurrentMonth = isCurrentMonth(day, displayMonth);
          const dayKey = day.toISODate();
          const hasEvents = dayKey && eventsPerDay.get(dayKey);

          return (
            <motion.button
              key={index}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => handleDateClick(day)}
              className={`
                h-7 w-7 flex items-center justify-center text-xs rounded-md
                relative transition-colors duration-100
                ${!isInCurrentMonth ? 'text-muted-foreground/50' : ''}
                ${isTodayDate ? 'bg-primary text-primary-foreground font-semibold' : ''}
                ${isSelected && !isTodayDate ? 'bg-accent text-accent-foreground' : ''}
                ${!isSelected && !isTodayDate ? 'hover:bg-muted' : ''}
              `}
              aria-label={`Select ${day.toFormat('MMMM d, yyyy')}`}
              data-testid={`mini-calendar-day-${dayKey}`}
            >
              {day.day}
              {hasEvents && !isTodayDate && (
                <span className="absolute bottom-0.5 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-primary" />
              )}
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}
