import { Plane, MapPin, X } from 'lucide-react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import type { TravelTime, TravelTimeOption } from '../types/calendar.types';

const TRAVEL_TIME_OPTIONS: TravelTimeOption[] = [15, 30, 60];

interface TravelTimeFieldProps {
  value: TravelTime | undefined;
  onChange: (value: TravelTime | undefined) => void;
}

export function TravelTimeField({ value, onChange }: TravelTimeFieldProps) {
  const handleMinutesChange = (minutes: TravelTimeOption) => {
    onChange({
      minutes,
      location: value?.location,
    });
  };

  const handleLocationChange = (location: string) => {
    if (value) {
      onChange({
        ...value,
        location,
      });
    }
  };

  const handleClear = () => {
    onChange(undefined);
  };

  const handleAddTravelTime = () => {
    onChange({
      minutes: 15,
      location: '',
    });
  };

  if (!value) {
    return (
      <Button
        type="button"
        variant="outline"
        className="w-full justify-start text-muted-foreground"
        onClick={handleAddTravelTime}
        data-testid="button-add-travel-time"
      >
        <Plane className="h-4 w-4 mr-2" />
        Add travel time
      </Button>
    );
  }

  return (
    <div className="space-y-3" data-testid="travel-time-field">
      <div className="flex items-center justify-between">
        <Label className="text-sm text-muted-foreground flex items-center gap-2">
          <Plane className="h-4 w-4" />
          Travel Time
        </Label>
        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="h-6 w-6"
          onClick={handleClear}
          aria-label="Remove travel time"
          data-testid="button-remove-travel-time"
        >
          <X className="h-4 w-4" />
        </Button>
      </div>

      <div className="flex gap-1">
        {TRAVEL_TIME_OPTIONS.map((minutes) => (
          <Button
            key={minutes}
            type="button"
            variant={value.minutes === minutes ? 'default' : 'outline'}
            size="sm"
            className="flex-1"
            onClick={() => handleMinutesChange(minutes)}
            aria-label={`${minutes} minutes travel time`}
            aria-pressed={value.minutes === minutes}
            data-testid={`button-travel-${minutes}`}
          >
            {minutes === 60 ? '1hr' : `${minutes}m`}
          </Button>
        ))}
      </div>

      <div className="relative">
        <MapPin className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          type="text"
          placeholder="Traveling from... (optional)"
          value={value.location || ''}
          onChange={(e) => handleLocationChange(e.target.value)}
          className="pl-8 h-9"
          aria-label="Travel from location"
          data-testid="input-travel-location"
        />
      </div>

      <p className="text-xs text-muted-foreground">
        A {value.minutes} minute buffer will be shown before this event
      </p>
    </div>
  );
}
