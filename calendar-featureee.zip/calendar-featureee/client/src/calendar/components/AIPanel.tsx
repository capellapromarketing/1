import { useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { DateTime } from 'luxon';
import { 
  X, 
  Sparkles, 
  RefreshCw, 
  Plus, 
  Clock, 
  Target,
  Coffee,
  Zap,
  CheckCircle2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { useCalendarStore } from '../store/calendarStore';
import { useDailyPlanner } from '../hooks/useDailyPlanner';
import type { SuggestedEvent, SuggestedBlock, Priority } from '../types/calendar.types';

const blockTypeIcons = {
  focus: Zap,
  break: Coffee,
  buffer: Clock,
};

const priorityColors = {
  high: 'text-destructive bg-destructive/10',
  medium: 'text-orange-500 bg-orange-500/10',
  low: 'text-muted-foreground bg-muted',
};

interface SuggestedEventCardProps {
  suggestion: SuggestedEvent;
  onAccept: () => void;
  onDismiss: () => void;
}

function SuggestedEventCard({ suggestion, onAccept, onDismiss }: SuggestedEventCardProps) {
  const start = DateTime.fromISO(suggestion.startTime);
  const end = DateTime.fromISO(suggestion.endTime);

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="p-3 rounded-lg border bg-card hover-elevate"
      data-testid={`suggestion-${suggestion.id}`}
    >
      <div className="flex items-start justify-between gap-2 mb-2">
        <div>
          <h4 className="font-medium text-sm">{suggestion.title}</h4>
          <p className="text-xs text-muted-foreground">
            {start.toFormat('h:mm a')} - {end.toFormat('h:mm a')}
          </p>
        </div>
        <Badge 
          variant="secondary"
          className={priorityColors[suggestion.priority]}
        >
          {suggestion.priority}
        </Badge>
      </div>
      <p className="text-xs text-muted-foreground mb-3">{suggestion.reason}</p>
      <div className="flex gap-2">
        <Button
          size="sm"
          onClick={onAccept}
          className="flex-1"
          data-testid={`button-accept-${suggestion.id}`}
        >
          <Plus className="h-3 w-3 mr-1" />
          Add
        </Button>
        <Button
          size="sm"
          variant="outline"
          onClick={onDismiss}
          className="flex-1"
          data-testid={`button-dismiss-${suggestion.id}`}
        >
          Dismiss
        </Button>
      </div>
    </motion.div>
  );
}

interface PriorityItemProps {
  priority: Priority;
}

function PriorityItem({ priority }: PriorityItemProps) {
  return (
    <div 
      className="flex items-center gap-3 p-2 rounded-md hover:bg-muted"
      data-testid={`priority-${priority.id}`}
    >
      <Target className="h-4 w-4 text-primary flex-shrink-0" />
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium truncate">{priority.title}</p>
        <p className="text-xs text-muted-foreground truncate">{priority.description}</p>
      </div>
      <span className="text-xs text-muted-foreground flex-shrink-0">
        ~{priority.timeEstimate}m
      </span>
    </div>
  );
}

export function AIPanel() {
  const { isAIPanelOpen, currentDate } = useCalendarStore();
  const {
    dailyPlan,
    isLoading,
    handleAcceptSuggestion,
    handleDismissSuggestion,
    handleClosePanel,
    handleRefreshPlan,
  } = useDailyPlanner();

  return (
    <AnimatePresence>
      {isAIPanelOpen && (
        <motion.div
          initial={{ width: 0, opacity: 0 }}
          animate={{ width: 360, opacity: 1 }}
          exit={{ width: 0, opacity: 0 }}
          transition={{ duration: 0.25, ease: 'easeInOut' }}
          className="h-full border-l bg-sidebar flex flex-col overflow-hidden"
          role="complementary"
          aria-label="AI Daily Planner"
          data-testid="ai-panel"
        >
          <div className="flex items-center justify-between p-4 border-b">
            <div className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-primary" />
              <h2 className="font-semibold">Daily Planner</h2>
            </div>
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={handleRefreshPlan}
                disabled={isLoading}
                aria-label="Refresh plan"
                data-testid="button-refresh-plan"
              >
                <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={handleClosePanel}
                aria-label="Close panel"
                data-testid="button-close-ai-panel"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <ScrollArea className="flex-1">
            {isLoading ? (
              <div className="flex flex-col items-center justify-center h-64 gap-3">
                <div className="relative">
                  <Sparkles className="h-8 w-8 text-primary animate-pulse" />
                  <div className="absolute inset-0 h-8 w-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                </div>
                <p className="text-sm text-muted-foreground">Analyzing your schedule...</p>
              </div>
            ) : dailyPlan ? (
              <div className="p-4 space-y-6">
                <div>
                  <p className="text-sm text-muted-foreground mb-2">
                    {currentDate.toFormat('EEEE, MMMM d')}
                  </p>
                  <p className="text-sm">{dailyPlan.summary}</p>
                </div>

                <Separator />

                {dailyPlan.suggestedEvents.length > 0 && (
                  <div>
                    <h3 className="text-sm font-medium mb-3 flex items-center gap-2">
                      <Clock className="h-4 w-4" />
                      Suggested Time Blocks
                    </h3>
                    <div className="space-y-2">
                      <AnimatePresence>
                        {dailyPlan.suggestedEvents.map((suggestion) => (
                          <SuggestedEventCard
                            key={suggestion.id}
                            suggestion={suggestion}
                            onAccept={() => handleAcceptSuggestion(suggestion)}
                            onDismiss={() => handleDismissSuggestion(suggestion.id)}
                          />
                        ))}
                      </AnimatePresence>
                    </div>
                  </div>
                )}

                {dailyPlan.priorities.length > 0 && (
                  <div>
                    <h3 className="text-sm font-medium mb-3 flex items-center gap-2">
                      <Target className="h-4 w-4" />
                      Today's Priorities
                    </h3>
                    <div className="space-y-1">
                      {dailyPlan.priorities.map((priority) => (
                        <PriorityItem key={priority.id} priority={priority} />
                      ))}
                    </div>
                  </div>
                )}

                {dailyPlan.suggestedBlocks.length > 0 && (
                  <div>
                    <h3 className="text-sm font-medium mb-3 flex items-center gap-2">
                      <Coffee className="h-4 w-4" />
                      Recommended Breaks
                    </h3>
                    <div className="space-y-2">
                      {dailyPlan.suggestedBlocks.map((block) => {
                        const Icon = blockTypeIcons[block.type];
                        const start = DateTime.fromISO(block.startTime);
                        const end = DateTime.fromISO(block.endTime);
                        
                        return (
                          <div 
                            key={block.id}
                            className="flex items-center gap-3 p-2 rounded-md bg-muted/50"
                            data-testid={`block-${block.id}`}
                          >
                            <Icon className="h-4 w-4 text-muted-foreground" />
                            <div className="flex-1">
                              <p className="text-sm">{block.label}</p>
                              <p className="text-xs text-muted-foreground">
                                {start.toFormat('h:mm a')} - {end.toFormat('h:mm a')}
                              </p>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-64 text-center p-4">
                <Sparkles className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="font-medium mb-2">No plan generated yet</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Click "Refresh" to generate AI suggestions for your day
                </p>
                <Button onClick={handleRefreshPlan} data-testid="button-generate-plan">
                  <Sparkles className="h-4 w-4 mr-2" />
                  Generate Plan
                </Button>
              </div>
            )}
          </ScrollArea>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
