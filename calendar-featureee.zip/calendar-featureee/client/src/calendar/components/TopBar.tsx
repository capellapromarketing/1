import { motion, AnimatePresence } from 'framer-motion';
import { 
  ChevronLeft, 
  ChevronRight, 
  Plus, 
  Sparkles,
  Search,
  X,
  Calendar as CalendarIcon,
  LayoutGrid,
  List,
  Clock
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { useCalendarStore } from '../store/calendarStore';
import { useNLPInput } from '../hooks/useNLPInput';
import type { CalendarViewType } from '../types/calendar.types';

const viewOptions: { value: CalendarViewType; label: string; icon: typeof CalendarIcon }[] = [
  { value: 'month', label: 'Month', icon: LayoutGrid },
  { value: 'week', label: 'Week', icon: CalendarIcon },
  { value: 'day', label: 'Day', icon: Clock },
  { value: 'agenda', label: 'Agenda', icon: List },
];

export function TopBar() {
  const {
    currentDate,
    currentView,
    setCurrentView,
    goToPrevious,
    goToNext,
    goToToday,
    setIsCreateModalOpen,
  } = useCalendarStore();

  const {
    inputValue,
    parsedEvent,
    isLoading,
    isInputFocused,
    inputRef,
    handleInputChange,
    handleClear,
    handleSubmit,
    handleKeyDown,
    setIsInputFocused,
  } = useNLPInput();

  const getViewLabel = () => {
    switch (currentView) {
      case 'month':
        return currentDate.toFormat('MMMM yyyy');
      case 'week':
        const weekStart = currentDate.startOf('week');
        const weekEnd = currentDate.endOf('week');
        if (weekStart.month === weekEnd.month) {
          return `${weekStart.toFormat('MMMM d')} - ${weekEnd.toFormat('d, yyyy')}`;
        }
        return `${weekStart.toFormat('MMM d')} - ${weekEnd.toFormat('MMM d, yyyy')}`;
      case 'day':
        return currentDate.toFormat('EEEE, MMMM d, yyyy');
      case 'agenda':
        return 'Agenda';
      default:
        return currentDate.toFormat('MMMM yyyy');
    }
  };

  const currentViewOption = viewOptions.find((v) => v.value === currentView);
  const ViewIcon = currentViewOption?.icon || CalendarIcon;

  return (
    <div className="flex items-center justify-between gap-4 px-4 py-3 border-b bg-background">
      <div className="flex items-center gap-3">
        <Button
          variant="outline"
          size="sm"
          onClick={goToToday}
          aria-label="Go to today"
          data-testid="button-today"
        >
          Today
        </Button>

        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            onClick={goToPrevious}
            aria-label="Previous period"
            data-testid="button-previous"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={goToNext}
            aria-label="Next period"
            data-testid="button-next"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>

        <h1 className="text-lg font-semibold min-w-[200px]" data-testid="text-current-date">
          {getViewLabel()}
        </h1>
      </div>

      <div className="flex-1 max-w-xl">
        <div className="relative">
          <div 
            className={`
              flex items-center gap-2 px-3 py-2 rounded-lg border
              transition-all duration-200
              ${isInputFocused 
                ? 'border-primary ring-2 ring-primary/20 bg-background' 
                : 'border-border bg-muted/50 hover:bg-muted'
              }
            `}
          >
            <Search className="h-4 w-4 text-muted-foreground flex-shrink-0" />
            <input
              ref={inputRef}
              type="text"
              value={inputValue}
              onChange={(e) => handleInputChange(e.target.value)}
              onFocus={() => setIsInputFocused(true)}
              onBlur={() => setIsInputFocused(false)}
              onKeyDown={handleKeyDown}
              placeholder="Add event... (Cmd+K)"
              className="flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
              aria-label="Natural language event input"
              data-testid="input-nl-event"
            />
            {inputValue && (
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6"
                onClick={handleClear}
                aria-label="Clear input"
                data-testid="button-clear-input"
              >
                <X className="h-3 w-3" />
              </Button>
            )}
            {isLoading && (
              <div className="h-4 w-4 border-2 border-primary border-t-transparent rounded-full animate-spin" />
            )}
          </div>

          <AnimatePresence>
            {parsedEvent && isInputFocused && (
              <motion.div
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -4 }}
                transition={{ duration: 0.15 }}
                className="absolute top-full left-0 right-0 mt-2 p-3 rounded-lg border bg-popover shadow-lg z-50"
                aria-live="polite"
                role="status"
                data-testid="preview-parsed-event"
              >
                <div className="text-sm">
                  <div className="flex items-center gap-2 mb-2">
                    <CalendarIcon className="h-4 w-4 text-primary" />
                    <span className="font-medium">{parsedEvent.title}</span>
                  </div>
                  {parsedEvent.startTime && (
                    <div className="text-xs text-muted-foreground mb-2">
                      {parsedEvent.date} {parsedEvent.isAllDay ? '(All day)' : `at ${parsedEvent.startTime?.split('T')[1]?.slice(0, 5)}`}
                    </div>
                  )}
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">
                      Confidence: {Math.round((parsedEvent.confidence || 0) * 100)}%
                    </span>
                    <Button
                      size="sm"
                      onClick={handleSubmit}
                      className="bg-primary hover:bg-primary/90"
                      data-testid="button-add-parsed-event"
                    >
                      Add Event
                    </Button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button 
              variant="outline" 
              size="sm"
              className="gap-2"
              aria-label="Switch calendar view"
              data-testid="button-view-switcher"
            >
              <ViewIcon className="h-4 w-4" />
              {currentViewOption?.label}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            {viewOptions.map((option) => (
              <DropdownMenuItem
                key={option.value}
                onClick={() => setCurrentView(option.value)}
                className="gap-2"
                data-testid={`menu-item-view-${option.value}`}
              >
                <option.icon className="h-4 w-4" />
                {option.label}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>

        <Button
          onClick={() => setIsCreateModalOpen(true)}
          size="sm"
          className="gap-2"
          aria-label="Create new event"
          data-testid="button-create-event"
        >
          <Plus className="h-4 w-4" />
          <span className="hidden sm:inline">New Event</span>
        </Button>
      </div>
    </div>
  );
}
