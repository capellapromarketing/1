import { useMemo, useState } from 'react';
import { useDroppable } from '@dnd-kit/core';
import { motion, AnimatePresence } from 'framer-motion';
import { DateTime } from 'luxon';
import { Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { useCalendarStore } from '../store/calendarStore';
import { useCalendarData } from '../hooks/useCalendarData';
import { getMonthDays, isToday, isCurrentMonth, getEventsForDate } from '../lib/dateUtils';
import { EventPill } from './EventPill';
import type { CalendarEvent } from '../types/calendar.types';

const WEEKDAY_LABELS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const MAX_VISIBLE_EVENTS = 4;

interface DayMoreEventsProps {
  events: CalendarEvent[];
  moreCount: number;
}

function DayMoreEvents({ events, moreCount }: DayMoreEventsProps) {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <button 
          className="w-full text-left text-xs text-primary hover:underline px-1.5 py-0.5"
          data-testid="button-show-more-events"
        >
          +{moreCount} more
        </button>
      </PopoverTrigger>
      <PopoverContent 
        className="w-64 p-2 space-y-1" 
        align="start"
        role="dialog"
        aria-label="More events"
      >
        {events.map((event) => (
          <EventPill key={event.id} event={event} compact />
        ))}
      </PopoverContent>
    </Popover>
  );
}

interface MonthDayCellProps {
  date: DateTime;
  events: CalendarEvent[];
  isCurrentMonthDay: boolean;
}

function MonthDayCell({ date, events, isCurrentMonthDay }: MonthDayCellProps) {
  const { setSelectedDate, setIsCreateModalOpen } = useCalendarStore();
  const isTodayDate = isToday(date);
  const dateKey = date.toISODate() || '';
  
  const { setNodeRef, isOver } = useDroppable({
    id: `day-${dateKey}`,
    data: { date, type: 'day' },
  });

  const visibleEvents = events.slice(0, MAX_VISIBLE_EVENTS);
  const hiddenEvents = events.slice(MAX_VISIBLE_EVENTS);
  const allDayEvents = events.filter((e) => e.isAllDay);
  const timedEvents = events.filter((e) => !e.isAllDay);

  const handleDayClick = () => {
    setSelectedDate(date);
  };

  const handleAddEvent = (e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedDate(date);
    setIsCreateModalOpen(true);
  };

  return (
    <motion.div
      ref={setNodeRef}
      className={`
        min-h-[120px] border-b border-r p-1 group cursor-pointer
        transition-colors duration-100
        ${!isCurrentMonthDay ? 'bg-muted/30' : 'bg-background'}
        ${isOver ? 'bg-primary/10' : ''}
        ${isTodayDate ? 'ring-1 ring-inset ring-primary' : ''}
      `}
      onClick={handleDayClick}
      data-testid={`month-day-${dateKey}`}
    >
      <div className="flex items-center justify-between mb-1">
        <span
          className={`
            text-sm w-7 h-7 flex items-center justify-center rounded-full
            ${isTodayDate ? 'bg-primary text-primary-foreground font-bold' : ''}
            ${!isCurrentMonthDay ? 'text-muted-foreground' : ''}
          `}
        >
          {date.day}
        </span>
        <Button
          variant="ghost"
          size="icon"
          className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
          onClick={handleAddEvent}
          aria-label={`Add event on ${date.toFormat('MMMM d')}`}
          data-testid={`button-add-event-${dateKey}`}
        >
          <Plus className="h-4 w-4" />
        </Button>
      </div>

      <div className="space-y-0.5">
        {allDayEvents.slice(0, 2).map((event) => (
          <EventPill
            key={event.id}
            event={event}
            compact
            showTime={false}
          />
        ))}
        
        {timedEvents.slice(0, MAX_VISIBLE_EVENTS - allDayEvents.slice(0, 2).length).map((event) => (
          <EventPill
            key={event.id}
            event={event}
            compact
          />
        ))}

        {hiddenEvents.length > 0 && (
          <DayMoreEvents events={hiddenEvents} moreCount={hiddenEvents.length} />
        )}
      </div>
    </motion.div>
  );
}

export function MonthView() {
  const { currentDate, userTimezone } = useCalendarStore();
  const { events, isLoading } = useCalendarData();

  const monthDays = useMemo(() => getMonthDays(currentDate), [currentDate]);

  const eventsPerDay = useMemo(() => {
    const map = new Map<string, CalendarEvent[]>();
    monthDays.forEach((day) => {
      const dateKey = day.toISODate();
      if (dateKey) {
        const dayEvents = getEventsForDate(events, day, userTimezone);
        map.set(dateKey, dayEvents);
      }
    });
    return map;
  }, [events, monthDays, userTimezone]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="h-8 w-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full" data-testid="month-view">
      <div className="grid grid-cols-7 border-b">
        {WEEKDAY_LABELS.map((day) => (
          <div
            key={day}
            className="px-2 py-3 text-sm font-medium text-muted-foreground text-center border-r last:border-r-0"
          >
            <span className="hidden md:inline">{day}</span>
            <span className="md:hidden">{day.slice(0, 3)}</span>
          </div>
        ))}
      </div>

      <div className="flex-1 grid grid-cols-7 auto-rows-fr">
        {monthDays.map((day, index) => {
          const dateKey = day.toISODate() || '';
          const dayEvents = eventsPerDay.get(dateKey) || [];
          const isCurrentMonthDay = isCurrentMonth(day, currentDate);

          return (
            <MonthDayCell
              key={index}
              date={day}
              events={dayEvents}
              isCurrentMonthDay={isCurrentMonthDay}
            />
          );
        })}
      </div>
    </div>
  );
}
