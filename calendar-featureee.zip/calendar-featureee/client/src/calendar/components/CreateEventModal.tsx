import { useMemo, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { motion, AnimatePresence } from 'framer-motion';
import { DateTime } from 'luxon';
import { 
  X, 
  Calendar as CalendarIcon,
  Clock,
  MapPin,
  AlignLeft,
  Users
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useCalendarStore } from '../store/calendarStore';
import { useCalendarData } from '../hooks/useCalendarData';
import { useRecurrence } from '../hooks/useRecurrence';
import { RecurringEventOptions } from './RecurringEventOptions';
import { TimezoneSelector } from './TimezoneSelector';
import { VideoCallPicker } from './VideoCallPicker';
import { TravelTimeField } from './TravelTimeField';
import { CALENDAR_COLORS, type VideoCallInfo, type TravelTime } from '../types/calendar.types';

const eventFormSchema = z.object({
  title: z.string().min(1, 'Title is required'),
  description: z.string().optional(),
  date: z.string().min(1, 'Date is required'),
  startTime: z.string().min(1, 'Start time is required'),
  endTime: z.string().min(1, 'End time is required'),
  isAllDay: z.boolean(),
  calendarId: z.string().min(1, 'Calendar is required'),
  location: z.string().optional(),
  timezone: z.string(),
});

type EventFormValues = z.infer<typeof eventFormSchema>;

export function CreateEventModal() {
  const { 
    isCreateModalOpen, 
    setIsCreateModalOpen, 
    selectedEvent,
    setSelectedEvent,
    calendars, 
    userTimezone,
    selectedDate,
  } = useCalendarStore();
  
  const { createEvent, updateEvent, isCreating, isUpdating } = useCalendarData();
  
  const {
    selectedFrequency,
    selectedInterval,
    selectedDays,
    hasEndDate,
    endDate,
    repeatCount,
    setSelectedFrequency,
    setSelectedInterval,
    setSelectedDays,
    setHasEndDate,
    setEndDate,
    setRepeatCount,
    buildRecurrenceRule,
    resetRecurrenceForm,
    initializeFromEvent,
  } = useRecurrence();

  const isEditing = !!selectedEvent;
  const [isRecurring, setIsRecurring] = useState(false);
  const [videoCall, setVideoCall] = useState<VideoCallInfo | undefined>(undefined);
  const [travelTime, setTravelTime] = useState<TravelTime | undefined>(undefined);

  const defaultDate = useMemo(() => {
    if (selectedEvent) {
      return DateTime.fromISO(selectedEvent.startTime).toISODate() || DateTime.now().toISODate();
    }
    return selectedDate?.toISODate() || DateTime.now().toISODate();
  }, [selectedEvent, selectedDate]);

  const defaultStartTime = useMemo(() => {
    if (selectedEvent) {
      return DateTime.fromISO(selectedEvent.startTime).toFormat('HH:mm');
    }
    return '09:00';
  }, [selectedEvent]);

  const defaultEndTime = useMemo(() => {
    if (selectedEvent) {
      return DateTime.fromISO(selectedEvent.endTime).toFormat('HH:mm');
    }
    return '10:00';
  }, [selectedEvent]);

  const form = useForm<EventFormValues>({
    resolver: zodResolver(eventFormSchema),
    defaultValues: {
      title: selectedEvent?.title || '',
      description: selectedEvent?.description || '',
      date: defaultDate || '',
      startTime: defaultStartTime,
      endTime: defaultEndTime,
      isAllDay: selectedEvent?.isAllDay || false,
      calendarId: selectedEvent?.calendarId || calendars[0]?.id || '',
      location: selectedEvent?.location || '',
      timezone: selectedEvent?.timezone || userTimezone,
    },
  });

  useEffect(() => {
    if (selectedEvent) {
      form.reset({
        title: selectedEvent.title,
        description: selectedEvent.description || '',
        date: DateTime.fromISO(selectedEvent.startTime).toISODate() || '',
        startTime: DateTime.fromISO(selectedEvent.startTime).toFormat('HH:mm'),
        endTime: DateTime.fromISO(selectedEvent.endTime).toFormat('HH:mm'),
        isAllDay: selectedEvent.isAllDay,
        calendarId: selectedEvent.calendarId,
        location: selectedEvent.location || '',
        timezone: selectedEvent.timezone,
      });
      setIsRecurring(!!selectedEvent.recurrence);
      setVideoCall(selectedEvent.videoCall);
      setTravelTime(selectedEvent.travelTime);
      if (selectedEvent.recurrence) {
        initializeFromEvent(selectedEvent);
      }
    }
  }, [selectedEvent, form, initializeFromEvent]);

  const handleClose = () => {
    setIsCreateModalOpen(false);
    setSelectedEvent(null);
    form.reset();
    resetRecurrenceForm();
    setIsRecurring(false);
    setVideoCall(undefined);
    setTravelTime(undefined);
  };

  const onSubmit = (values: EventFormValues) => {
    const startDateTime = values.isAllDay
      ? DateTime.fromISO(values.date).startOf('day')
      : DateTime.fromISO(`${values.date}T${values.startTime}`);
    
    const endDateTime = values.isAllDay
      ? DateTime.fromISO(values.date).endOf('day')
      : DateTime.fromISO(`${values.date}T${values.endTime}`);

    const eventData = {
      title: values.title,
      description: values.description,
      startTime: startDateTime.toISO() || '',
      endTime: endDateTime.toISO() || '',
      timezone: values.timezone,
      isAllDay: values.isAllDay,
      calendarId: values.calendarId,
      location: values.location,
      recurrence: isRecurring ? buildRecurrenceRule() : undefined,
      videoCall,
      travelTime,
    };

    if (isEditing && selectedEvent) {
      updateEvent({ eventId: selectedEvent.id, updates: eventData });
    } else {
      createEvent({
        id: `evt-${Date.now()}`,
        ...eventData,
      });
    }

    handleClose();
  };

  const getCalendarColor = (calendarId: string) => {
    const calendar = calendars.find((c) => c.id === calendarId);
    const color = CALENDAR_COLORS.find((c) => c.id === calendar?.color);
    return color?.hex || '#8E8E93';
  };

  return (
    <AnimatePresence>
      {isCreateModalOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.15 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
        >
          <div 
            className="absolute inset-0 bg-black/50" 
            onClick={handleClose}
            aria-hidden="true"
          />
          
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="relative bg-background rounded-lg shadow-xl w-full max-w-[560px] max-h-[90vh] overflow-hidden"
            role="dialog"
            aria-modal="true"
            aria-labelledby="create-event-title"
            data-testid="create-event-modal"
          >
            <div className="flex items-center justify-between px-6 py-4 border-b">
              <h2 id="create-event-title" className="text-lg font-semibold">
                {isEditing ? 'Edit Event' : 'Create Event'}
              </h2>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleClose}
                aria-label="Close modal"
                data-testid="button-close-modal"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>

            <ScrollArea className="max-h-[calc(90vh-140px)]">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="p-6 space-y-6">
                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Input
                            {...field}
                            placeholder="Add title"
                            className="text-xl font-semibold border-0 border-b rounded-none px-0 focus-visible:ring-0 focus-visible:border-primary"
                            autoFocus
                            data-testid="input-event-title"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="space-y-4">
                    <div className="flex items-center gap-4">
                      <CalendarIcon className="h-4 w-4 text-muted-foreground" />
                      <FormField
                        control={form.control}
                        name="date"
                        render={({ field }) => (
                          <FormItem className="flex-1">
                            <FormControl>
                              <Input
                                {...field}
                                type="date"
                                className="h-9"
                                data-testid="input-event-date"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="isAllDay"
                        render={({ field }) => (
                          <FormItem className="flex items-center gap-2">
                            <FormLabel className="text-sm text-muted-foreground">All day</FormLabel>
                            <FormControl>
                              <Switch
                                checked={field.value}
                                onCheckedChange={field.onChange}
                                data-testid="switch-all-day"
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                    </div>

                    {!form.watch('isAllDay') && (
                      <div className="flex items-center gap-4">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <div className="flex items-center gap-2 flex-1">
                          <FormField
                            control={form.control}
                            name="startTime"
                            render={({ field }) => (
                              <FormItem className="flex-1">
                                <FormControl>
                                  <Input
                                    {...field}
                                    type="time"
                                    className="h-9"
                                    data-testid="input-start-time"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <span className="text-muted-foreground">-</span>
                          <FormField
                            control={form.control}
                            name="endTime"
                            render={({ field }) => (
                              <FormItem className="flex-1">
                                <FormControl>
                                  <Input
                                    {...field}
                                    type="time"
                                    className="h-9"
                                    data-testid="input-end-time"
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>
                    )}

                    <FormField
                      control={form.control}
                      name="timezone"
                      render={({ field }) => (
                        <FormItem>
                          <TimezoneSelector
                            value={field.value}
                            onChange={field.onChange}
                          />
                        </FormItem>
                      )}
                    />

                    <div className="flex items-center gap-4">
                      <div
                        className="w-4 h-4 rounded-full flex-shrink-0"
                        style={{ backgroundColor: getCalendarColor(form.watch('calendarId')) }}
                      />
                      <FormField
                        control={form.control}
                        name="calendarId"
                        render={({ field }) => (
                          <FormItem className="flex-1">
                            <Select
                              value={field.value}
                              onValueChange={field.onChange}
                            >
                              <FormControl>
                                <SelectTrigger 
                                  className="h-9"
                                  data-testid="select-calendar"
                                >
                                  <SelectValue placeholder="Select calendar" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {calendars.map((cal) => (
                                  <SelectItem key={cal.id} value={cal.id}>
                                    <div className="flex items-center gap-2">
                                      <div
                                        className="w-3 h-3 rounded-full"
                                        style={{ backgroundColor: getCalendarColor(cal.id) }}
                                      />
                                      {cal.name}
                                    </div>
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="location"
                      render={({ field }) => (
                        <FormItem>
                          <div className="flex items-center gap-4">
                            <MapPin className="h-4 w-4 text-muted-foreground" />
                            <FormControl>
                              <Input
                                {...field}
                                placeholder="Add location"
                                className="h-9"
                                data-testid="input-location"
                              />
                            </FormControl>
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <div className="flex items-start gap-4">
                            <AlignLeft className="h-4 w-4 text-muted-foreground mt-2" />
                            <FormControl>
                              <Textarea
                                {...field}
                                placeholder="Add description"
                                className="min-h-[80px] resize-none"
                                data-testid="textarea-description"
                              />
                            </FormControl>
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="space-y-4 pt-4 border-t">
                    <RecurringEventOptions
                      isRecurring={isRecurring}
                      frequency={selectedFrequency}
                      interval={selectedInterval}
                      selectedDays={selectedDays}
                      hasEndDate={hasEndDate}
                      endDate={endDate}
                      repeatCount={repeatCount}
                      onIsRecurringChange={setIsRecurring}
                      onFrequencyChange={setSelectedFrequency}
                      onIntervalChange={setSelectedInterval}
                      onSelectedDaysChange={setSelectedDays}
                      onHasEndDateChange={setHasEndDate}
                      onEndDateChange={setEndDate}
                      onRepeatCountChange={setRepeatCount}
                    />
                  </div>

                  <div className="space-y-4 pt-4 border-t">
                    <VideoCallPicker
                      value={videoCall}
                      onChange={setVideoCall}
                    />
                  </div>

                  <div className="space-y-4 pt-4 border-t">
                    <TravelTimeField
                      value={travelTime}
                      onChange={setTravelTime}
                    />
                  </div>
                </form>
              </Form>
            </ScrollArea>

            <div className="flex items-center justify-end gap-3 px-6 py-4 border-t bg-muted/30">
              <Button
                variant="outline"
                onClick={handleClose}
                data-testid="button-cancel"
              >
                Cancel
              </Button>
              <Button
                onClick={form.handleSubmit(onSubmit)}
                disabled={isCreating || isUpdating}
                data-testid="button-save-event"
              >
                {isCreating || isUpdating ? (
                  <div className="h-4 w-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin mr-2" />
                ) : null}
                {isEditing ? 'Save Changes' : 'Create Event'}
              </Button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
