import { DateTime, Duration, Interval } from 'luxon';
import type { CalendarEvent, TimeSlot } from '../types/calendar.types';

export function getWeekDays(date: DateTime): DateTime[] {
  const startOfWeek = date.startOf('week');
  return Array.from({ length: 7 }, (_, i) => startOfWeek.plus({ days: i }));
}

export function getMonthDays(date: DateTime): DateTime[] {
  const startOfMonth = date.startOf('month');
  const endOfMonth = date.endOf('month');
  const startOfCalendar = startOfMonth.startOf('week');
  const endOfCalendar = endOfMonth.endOf('week');

  const days: DateTime[] = [];
  let current = startOfCalendar;

  while (current <= endOfCalendar) {
    days.push(current);
    current = current.plus({ days: 1 });
  }

  return days;
}

export function formatDateRange(start: DateTime, end: DateTime): string {
  if (start.hasSame(end, 'day')) {
    return `${start.toFormat('h:mm a')} - ${end.toFormat('h:mm a')}`;
  }
  return `${start.toFormat('MMM d, h:mm a')} - ${end.toFormat('MMM d, h:mm a')}`;
}

export function formatTimeSlot(hour: number, minute: number): string {
  const dt = DateTime.fromObject({ hour, minute });
  return dt.toFormat('h:mm a');
}

export function getTimeSlots(intervalMinutes: number = 60): TimeSlot[] {
  const slots: TimeSlot[] = [];
  for (let hour = 0; hour < 24; hour++) {
    for (let minute = 0; minute < 60; minute += intervalMinutes) {
      slots.push({
        hour,
        minute,
        label: formatTimeSlot(hour, minute),
      });
    }
  }
  return slots;
}

export function parseEventDateTime(event: CalendarEvent): { start: DateTime; end: DateTime } {
  const start = DateTime.fromISO(event.startTime, { zone: event.timezone });
  const end = DateTime.fromISO(event.endTime, { zone: event.timezone });
  return { start, end };
}

export function convertToUserTimezone(dateTime: DateTime, userTimezone: string): DateTime {
  return dateTime.setZone(userTimezone);
}

export function getEventDuration(event: CalendarEvent): Duration {
  const { start, end } = parseEventDateTime(event);
  return end.diff(start);
}

export function isEventOnDate(event: CalendarEvent, date: DateTime, userTimezone: string): boolean {
  const { start, end } = parseEventDateTime(event);
  const startInUserTz = convertToUserTimezone(start, userTimezone);
  const endInUserTz = convertToUserTimezone(end, userTimezone);
  
  const dayStart = date.startOf('day');
  const dayEnd = date.endOf('day');
  
  const eventInterval = Interval.fromDateTimes(startInUserTz, endInUserTz);
  const dayInterval = Interval.fromDateTimes(dayStart, dayEnd);
  
  return eventInterval.overlaps(dayInterval);
}

export function getEventsForDate(
  events: CalendarEvent[],
  date: DateTime,
  userTimezone: string
): CalendarEvent[] {
  return events.filter((event) => isEventOnDate(event, date, userTimezone));
}

export function getEventsForWeek(
  events: CalendarEvent[],
  date: DateTime,
  userTimezone: string
): CalendarEvent[] {
  const weekStart = date.startOf('week');
  const weekEnd = date.endOf('week');
  
  return events.filter((event) => {
    const { start, end } = parseEventDateTime(event);
    const startInUserTz = convertToUserTimezone(start, userTimezone);
    const endInUserTz = convertToUserTimezone(end, userTimezone);
    
    const eventInterval = Interval.fromDateTimes(startInUserTz, endInUserTz);
    const weekInterval = Interval.fromDateTimes(weekStart, weekEnd);
    
    return eventInterval.overlaps(weekInterval);
  });
}

export function snapToGrid(dateTime: DateTime, gridMinutes: number = 15): DateTime {
  const minute = dateTime.minute;
  const snappedMinute = Math.round(minute / gridMinutes) * gridMinutes;
  return dateTime.set({ minute: snappedMinute % 60, second: 0, millisecond: 0 });
}

export function calculateTravelBuffer(event: CalendarEvent): { bufferStart: DateTime; bufferEnd: DateTime } | null {
  if (!event.travelTime) return null;
  
  const { start } = parseEventDateTime(event);
  const bufferStart = start.minus({ minutes: event.travelTime.minutes });
  const bufferEnd = start;
  
  return { bufferStart, bufferEnd };
}

export function getEventPositionInDay(
  event: CalendarEvent,
  userTimezone: string,
  hourHeight: number = 60
): { top: number; height: number } {
  const { start, end } = parseEventDateTime(event);
  const startInUserTz = convertToUserTimezone(start, userTimezone);
  const endInUserTz = convertToUserTimezone(end, userTimezone);
  
  const startMinutes = startInUserTz.hour * 60 + startInUserTz.minute;
  const endMinutes = endInUserTz.hour * 60 + endInUserTz.minute;
  const durationMinutes = endMinutes - startMinutes;
  
  const top = (startMinutes / 60) * hourHeight;
  const height = Math.max((durationMinutes / 60) * hourHeight, hourHeight / 4);
  
  return { top, height };
}

export function isDifferentTimezone(eventTimezone: string, userTimezone: string): boolean {
  const now = DateTime.now();
  const eventTzOffset = now.setZone(eventTimezone).offset;
  const userTzOffset = now.setZone(userTimezone).offset;
  return eventTzOffset !== userTzOffset;
}

export function formatTimezoneOffset(timezone: string): string {
  const dt = DateTime.now().setZone(timezone);
  const offset = dt.toFormat('ZZ');
  const abbrev = dt.toFormat('ZZZZ');
  return `${abbrev} (${offset})`;
}

export function isToday(date: DateTime): boolean {
  return date.hasSame(DateTime.now(), 'day');
}

export function isCurrentMonth(date: DateTime, referenceDate: DateTime): boolean {
  return date.hasSame(referenceDate, 'month');
}

export function getRelativeDateLabel(date: DateTime): string {
  const now = DateTime.now();
  const diff = date.startOf('day').diff(now.startOf('day'), 'days').days;
  
  if (diff === 0) return 'Today';
  if (diff === 1) return 'Tomorrow';
  if (diff === -1) return 'Yesterday';
  if (diff > 1 && diff < 7) return date.toFormat('EEEE');
  return date.toFormat('MMM d');
}

export function getDayOfWeekIndex(date: DateTime): number {
  return date.weekday - 1;
}

export function getWeekNumber(date: DateTime): number {
  return date.weekNumber;
}
