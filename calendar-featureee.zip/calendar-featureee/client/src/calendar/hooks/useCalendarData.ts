import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { DateTime } from 'luxon';
import { useCalendarStore } from '../store/calendarStore';
import { expandAllRecurringEvents } from '../lib/recurrence';
import type { CalendarEvent, Calendar, Task } from '../types/calendar.types';

export function useCalendarData() {
  const queryClient = useQueryClient();
  const { 
    events, 
    calendars, 
    tasks, 
    currentDate, 
    currentView, 
    userTimezone,
    addEvent,
    updateEvent,
    deleteEvent,
    pushToUndoStack,
  } = useCalendarStore();

  const getViewRange = (): { start: DateTime; end: DateTime } => {
    switch (currentView) {
      case 'month':
        return {
          start: currentDate.startOf('month').startOf('week'),
          end: currentDate.endOf('month').endOf('week'),
        };
      case 'week':
        return {
          start: currentDate.startOf('week'),
          end: currentDate.endOf('week'),
        };
      case 'day':
        return {
          start: currentDate.startOf('day'),
          end: currentDate.endOf('day'),
        };
      case 'agenda':
        return {
          start: currentDate.startOf('day'),
          end: currentDate.plus({ weeks: 2 }).endOf('day'),
        };
      default:
        return {
          start: currentDate.startOf('week'),
          end: currentDate.endOf('week'),
        };
    }
  };

  const eventsQuery = useQuery({
    queryKey: ['calendar-events', currentDate.toISODate(), currentView],
    queryFn: async () => {
      const { start, end } = getViewRange();
      const visibleCalendarIds = calendars
        .filter((cal) => cal.isVisible)
        .map((cal) => cal.id);

      const filteredEvents = events.filter((event) =>
        visibleCalendarIds.includes(event.calendarId)
      );

      const expandedEvents = expandAllRecurringEvents(filteredEvents, start, end);
      
      return expandedEvents;
    },
    staleTime: 1000 * 60,
  });

  const calendarsQuery = useQuery({
    queryKey: ['calendars'],
    queryFn: async () => calendars,
    staleTime: 1000 * 60 * 5,
  });

  const tasksQuery = useQuery({
    queryKey: ['tasks'],
    queryFn: async () => tasks,
    staleTime: 1000 * 60,
  });

  const createEventMutation = useMutation({
    mutationFn: async (newEvent: CalendarEvent) => {
      await new Promise((resolve) => setTimeout(resolve, 100));
      return newEvent;
    },
    onMutate: async (newEvent) => {
      await queryClient.cancelQueries({ queryKey: ['calendar-events'] });
      const previousEvents = queryClient.getQueryData(['calendar-events']);
      addEvent(newEvent);
      return { previousEvents };
    },
    onError: (err, newEvent, context) => {
      if (context?.previousEvents) {
        queryClient.setQueryData(['calendar-events'], context.previousEvents);
      }
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ['calendar-events'] });
    },
  });

  const updateEventMutation = useMutation({
    mutationFn: async ({ eventId, updates }: { eventId: string; updates: Partial<CalendarEvent> }) => {
      await new Promise((resolve) => setTimeout(resolve, 100));
      return { eventId, updates };
    },
    onMutate: async ({ eventId, updates }) => {
      await queryClient.cancelQueries({ queryKey: ['calendar-events'] });
      const previousEvents = queryClient.getQueryData(['calendar-events']);
      
      const eventToUpdate = events.find((e) => e.id === eventId);
      if (eventToUpdate) {
        pushToUndoStack(eventToUpdate);
      }
      
      updateEvent(eventId, updates);
      return { previousEvents };
    },
    onError: (err, variables, context) => {
      if (context?.previousEvents) {
        queryClient.setQueryData(['calendar-events'], context.previousEvents);
      }
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ['calendar-events'] });
    },
  });

  const deleteEventMutation = useMutation({
    mutationFn: async (eventId: string) => {
      await new Promise((resolve) => setTimeout(resolve, 100));
      return eventId;
    },
    onMutate: async (eventId) => {
      await queryClient.cancelQueries({ queryKey: ['calendar-events'] });
      const previousEvents = queryClient.getQueryData(['calendar-events']);
      
      const eventToDelete = events.find((e) => e.id === eventId);
      if (eventToDelete) {
        pushToUndoStack(eventToDelete);
      }
      
      deleteEvent(eventId);
      return { previousEvents };
    },
    onError: (err, eventId, context) => {
      if (context?.previousEvents) {
        queryClient.setQueryData(['calendar-events'], context.previousEvents);
      }
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ['calendar-events'] });
    },
  });

  return {
    events: eventsQuery.data || [],
    calendars: calendarsQuery.data || [],
    tasks: tasksQuery.data || [],
    isLoading: eventsQuery.isLoading,
    isError: eventsQuery.isError,
    error: eventsQuery.error,
    createEvent: createEventMutation.mutate,
    updateEvent: updateEventMutation.mutate,
    deleteEvent: deleteEventMutation.mutate,
    isCreating: createEventMutation.isPending,
    isUpdating: updateEventMutation.isPending,
    isDeleting: deleteEventMutation.isPending,
  };
}
