import { useCallback } from 'react';
import { useMutation } from '@tanstack/react-query';
import { DateTime } from 'luxon';
import { generateDailyPlan } from '../mocks/fetchers';
import { useCalendarStore } from '../store/calendarStore';
import type { DailyPlan, CalendarEvent, SuggestedEvent } from '../types/calendar.types';

export function useDailyPlanner() {
  const { 
    currentDate,
    userTimezone,
    dailyPlan,
    setDailyPlan,
    setIsAIPanelOpen,
    setIsAIConsentModalOpen,
    addEvent,
    calendars,
  } = useCalendarStore();

  const planMutation = useMutation({
    mutationFn: async ({ userId, date }: { userId: string; date: DateTime }) => {
      return generateDailyPlan(userId, date);
    },
    onSuccess: (result) => {
      setDailyPlan(result);
      setIsAIPanelOpen(true);
    },
    onError: (error) => {
      console.error('Failed to generate daily plan:', error);
    },
  });

  const handlePlanMyDay = useCallback(() => {
    const hasAIConsent = localStorage.getItem('aiConsent') === 'true';
    
    if (!hasAIConsent) {
      setIsAIConsentModalOpen(true);
      return;
    }

    planMutation.mutate({
      userId: 'user-1',
      date: currentDate,
    });
  }, [currentDate, planMutation, setIsAIConsentModalOpen]);

  const handleAcceptConsent = useCallback(() => {
    localStorage.setItem('aiConsent', 'true');
    setIsAIConsentModalOpen(false);
    
    planMutation.mutate({
      userId: 'user-1',
      date: currentDate,
    });
  }, [currentDate, planMutation, setIsAIConsentModalOpen]);

  const handleDeclineConsent = useCallback(() => {
    setIsAIConsentModalOpen(false);
  }, [setIsAIConsentModalOpen]);

  const handleAcceptSuggestion = useCallback((suggestion: SuggestedEvent) => {
    const defaultCalendar = calendars.find((c) => c.isDefault) || calendars[0];
    
    const newEvent: CalendarEvent = {
      id: `evt-ai-${Date.now()}`,
      title: suggestion.title,
      description: suggestion.reason,
      startTime: suggestion.startTime,
      endTime: suggestion.endTime,
      timezone: userTimezone,
      isAllDay: false,
      calendarId: defaultCalendar?.id || 'cal-work',
    };

    addEvent(newEvent);

    if (dailyPlan) {
      setDailyPlan({
        ...dailyPlan,
        suggestedEvents: dailyPlan.suggestedEvents.filter((s) => s.id !== suggestion.id),
      });
    }
  }, [addEvent, calendars, userTimezone, dailyPlan, setDailyPlan]);

  const handleDismissSuggestion = useCallback((suggestionId: string) => {
    if (dailyPlan) {
      setDailyPlan({
        ...dailyPlan,
        suggestedEvents: dailyPlan.suggestedEvents.filter((s) => s.id !== suggestionId),
      });
    }
  }, [dailyPlan, setDailyPlan]);

  const handleClosePanel = useCallback(() => {
    setIsAIPanelOpen(false);
  }, [setIsAIPanelOpen]);

  const handleRefreshPlan = useCallback(() => {
    planMutation.mutate({
      userId: 'user-1',
      date: currentDate,
    });
  }, [currentDate, planMutation]);

  return {
    dailyPlan,
    isLoading: planMutation.isPending,
    isError: planMutation.isError,
    error: planMutation.error,
    handlePlanMyDay,
    handleAcceptConsent,
    handleDeclineConsent,
    handleAcceptSuggestion,
    handleDismissSuggestion,
    handleClosePanel,
    handleRefreshPlan,
  };
}
