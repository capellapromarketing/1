# CAPELLA PRO CALENDAR V1.5 — DESIGN GUIDELINES

## BRAND & COLOR SYSTEM

**Primary Action Color:** Aquamarine (Capella Pro Global CTA)
- All global CTAs: "Plan my day" button, modal confirm buttons, NL input action buttons
- Modal primary actions, keyboard shortcuts, focus states

**Calendar Category Colors:**
- Blue (#007AFF), Green (#34C759), Purple (#AF52DE), Orange, Red, Yellow, Cyan, Gray
- Used for calendar event pills and category identification

## TYPOGRAPHY & SPACING

**Font Family:** Inter (Google Fonts CDN)
- Headings: font-semibold
- Body: font-normal
- UI labels: text-sm, text-xs

**Spacing System:** Tailwind primitives
- Container padding: p-4, p-6
- Component spacing: space-y-4, gap-4
- Event pills: 24px height minimum

## LAYOUT ARCHITECTURE

**Main Canvas:**
- TopBar (NL input pill, view switcher, "Plan my day" button with Aquamarine)
- Sidebar (280px): MiniCalendar, SidebarCalendarsList, draggable tasks
- Calendar views: Month/Week/Day/Agenda (responsive grid)
- AIPanel (360px right): slides in on "Plan my day" action

**Responsive Breakpoints:**
- Sidebar collapses at 1024px
- Mobile-first grid adjustments

## COMPONENT SPECIFICATIONS

**Event Pills:**
- 24px min-height
- 3px left border (calendar color)
- Icons: camera SVG (video), 🔁 (recurring), ✈️ (travel time)
- 2px timezone stripe for non-local events
- Rounded corners: rounded-lg

**Modals & Popovers:**
- EventPopover: 280px width, positioned near event, shadow-lg
- CreateEventModal: 560px width, react-hook-form layout, Aquamarine confirm button
- AIConsentModal: centered, shadow-xl
- Framer Motion: 150ms modals, 250ms panels

**Interactive Elements:**
- Buttons: rounded-lg, shadow-md, hover lift (Framer Motion)
- Drag handles: cursor-grab, dnd-kit overlay
- Time blocks: 15min snap grid, lighter travel buffer blocks
- Focus states: focus:ring-2 focus:ring-aquamarine

## VIEW-SPECIFIC DESIGN

**Month View:**
- 4 events per day maximum
- "+X more" expand interaction
- Grid: rounded cells, hover states

**Week/Day Views:**
- Timeline with hourly markers
- Drag/resize with dnd-kit
- Travel time: lighter opacity blocks before/after events
- Timezone boundaries: documented behavior matrix

**Agenda View:**
- List format with date headers
- Grouped by day, chronological order

## ACCESSIBILITY & INTERACTION

**Keyboard Navigation:**
- Cmd+K: NL command bar
- ESC: close modals, clear NL input
- Tab/Enter/Arrows: full navigation
- focus:ring-2 on all interactive elements

**ARIA Implementation:**
- aria-label on all buttons
- role="dialog" on modals
- aria-live="polite" on NL parsing preview
- Semantic HTML throughout

## ANIMATION PRINCIPLES

**Framer Motion Usage:**
- Modals: 150ms fade + scale
- Panels: 250ms slide
- Hover lift: subtle (2px translateY)
- Drag preview: smooth shadow transition
- Minimize distracting animations

## MOCK DATA VISUALIZATION

Events must demonstrate:
- 2 with travel time (lighter blocks)
- 1 all-day (banner style)
- 1 multi-day (spans cells)
- 1 recurring (🔁 icon)
- 1 video call (camera icon)
- 1 different timezone (2px stripe)

## DESIGN COHERENCE

- Tailwind utilities only: no custom CSS
- Consistent rounded-lg, shadow-md pattern
- Inter font throughout
- Aquamarine for all primary actions
- Category colors for event organization
- Professional, clean, productivity-focused aesthetic