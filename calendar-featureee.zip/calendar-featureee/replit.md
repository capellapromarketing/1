# Capella Pro Calendar V1.5

## Overview

Capella Pro Calendar is a modern, full-featured calendar application built as a front-end focused React application. It provides a comprehensive scheduling interface with support for multiple calendar views (month, week, day, agenda), natural language event parsing, drag-and-drop event management, recurring events, timezone handling, and AI-powered daily planning suggestions.

The application emphasizes a clean, professional design with the Capella brand's signature aquamarine color for primary actions, and uses a carefully designed component system built on shadcn/ui and Radix UI primitives.

## Recent Changes

**November 29, 2025 - Replit Environment Setup**
- Imported project from GitHub repository
- Installed Node.js 20 and all npm dependencies
- Configured development workflow to run on port 5000
- Set up deployment configuration for production (autoscale mode with build and start scripts)
- Verified application runs successfully with all features working

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework Stack:**
- **React 18** with TypeScript for type-safe component development
- **Vite** as the build tool and development server
- **Wouter** for lightweight client-side routing
- **TanStack Query** (React Query) for data fetching and caching
- **Zustand** for global state management

**UI Component Library:**
- **shadcn/ui** components based on Radix UI primitives
- **Tailwind CSS** for styling with custom design tokens
- **Framer Motion** for animations (150ms modals, 250ms panels)
- **Lucide React** for icons

**Calendar-Specific Libraries:**
- **Luxon** for date/time manipulation and timezone handling
- **rrule.js** for recurring event calculations (daily, weekly, monthly only)
- **dnd-kit** for drag-and-drop functionality
- **react-hook-form** with Zod validation for form handling

### Data Management Strategy

**Client-Side Data Model:**
The application uses a pure client-side architecture with mock data fetchers. All data operations are performed in-memory through Zustand stores, with no backend API calls. Mock async functions simulate network delays for realistic interactions.

**State Management:**
- **Global State (Zustand):** Calendar events, tasks, calendars, user preferences, UI state (modal visibility, current view, selected dates)
- **Server State (React Query):** Used with mock fetchers for consistent data handling patterns
- **Local State:** Form state, drag-and-drop preview state, temporary UI state

**Key Data Structures:**
- `CalendarEvent`: Events with recurrence rules, timezone info, video calls, travel time
- `Task`: Draggable tasks that can be converted to events
- `Calendar`: Calendar categories with visibility toggles and color coding
- `DailyPlan`: AI-generated suggestions for event scheduling

### Component Architecture

**Layout Structure:**
- **TopBar:** Natural language input, view switcher, "Plan my day" button
- **Sidebar (280px):** Mini calendar, calendar list with visibility toggles, draggable task list
- **Main Canvas:** Calendar views (Month/Week/Day/Agenda) with responsive grid
- **AIPanel (360px):** Slides in from right for AI-powered daily planning
- **Modals:** Event creation/editing, recurring event options, AI consent

**Responsive Design:**
- Sidebar collapses at 1024px breakpoint
- Mobile-first grid adjustments
- Touch-friendly drag-and-drop interactions

### Calendar Features

**Multiple View Modes:**
- **Month View:** Grid with 4 visible events per day, "+X more" expansion
- **Week View:** Timeline with hourly slots, drag-to-resize events
- **Day View:** Single-day detailed timeline
- **Agenda View:** Linear list of upcoming events (2-week range)

**Event Management:**
- Create events via natural language input or modal form
- Drag-and-drop to reschedule events
- Recurring events with simple patterns (daily/weekly/monthly)
- Edit modes: "This event only" or "This and following events"
- Timezone support with visual indicators for non-local events
- Video call integration (Zoom, Google Meet, Teams)
- Travel time buffers (15/30/60 minutes)

**Natural Language Processing:**
- Client-side parsing of event descriptions
- Live preview with confidence indicators
- Debounced input (300ms) to reduce processing
- Supports time expressions, dates, durations

**AI Daily Planning:**
- Generates suggested events and time blocks
- Consent modal for first-time usage (stored in localStorage)
- Suggested event types: meetings, focus blocks, breaks, buffers
- Priority-based recommendations (high/medium/low)

### Design System

**Brand Colors:**
- **Primary Action (Aquamarine):** `hsl(174 65% 48%)` for all CTAs ("Plan my day", confirm buttons, focus states)
- **Calendar Category Colors:** Blue, Green, Purple, Orange, Red, Yellow, Cyan, Gray for event categorization

**Typography:**
- **Font:** Inter (via Google Fonts CDN)
- **Weights:** Semibold for headings, normal for body text
- **Sizes:** sm/xs for UI labels

**Component Styling:**
- Event pills: 24px min-height, 3px left border (calendar color), rounded-lg corners
- Modals: 280px (popovers) to 560px (create modal)
- Shadows: shadow-lg for popovers, shadow-xl for modals
- Animations: Consistent Framer Motion durations (150ms/250ms)

### Keyboard Shortcuts

- `Cmd/Ctrl + K`: Focus natural language input
- `N`: Create new event
- `←/→`: Navigate previous/next period
- `T`: Go to today
- `1/2/3/4`: Switch to Month/Week/Day/Agenda views
- `S`: Toggle sidebar
- `Esc`: Close modals/popovers
- `Cmd/Ctrl + Z`: Undo last action

### Undo/Redo System

Client-side undo stack tracks event modifications with toast-based undo UI. 5-second window to reverse deletions or modifications.

## External Dependencies

### Core Framework Dependencies

- **@tanstack/react-query**: Data fetching and caching layer
- **zustand**: Global state management
- **wouter**: Client-side routing
- **react-hook-form**: Form state management
- **@hookform/resolvers**: Zod integration for form validation
- **zod**: Schema validation

### UI Component Libraries

- **@radix-ui/react-***: Headless UI primitives (accordion, dialog, dropdown, popover, select, etc.)
- **shadcn/ui**: Pre-styled component library built on Radix
- **framer-motion**: Animation library
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Component variant styling
- **clsx** + **tailwind-merge**: Conditional className utilities

### Calendar & Date Utilities

- **luxon**: Modern date/time library with timezone support
- **rrule**: Recurring event calculations (RFC 5545)
- **@dnd-kit/core**, **@dnd-kit/sortable**, **@dnd-kit/utilities**: Drag-and-drop functionality

### Icon Libraries

- **lucide-react**: Primary icon set
- **react-icons**: Supplementary icons (social media logos for video providers)

### Development Tools

- **vite**: Build tool and dev server
- **typescript**: Type checking
- **@vitejs/plugin-react**: React support for Vite
- **postcss** + **autoprefixer**: CSS processing

### Optional Server Infrastructure

While the application is designed to run client-side only, the repository includes Express.js boilerplate and Drizzle ORM configuration for potential future backend integration:

- **express**: HTTP server framework
- **drizzle-orm**: TypeScript ORM
- **@neondatabase/serverless**: PostgreSQL database driver
- **drizzle-kit**: Database migration tool

**Note:** The calendar features currently use mock data fetchers in `client/src/calendar/mocks/fetchers.ts` and do not connect to the server infrastructure.