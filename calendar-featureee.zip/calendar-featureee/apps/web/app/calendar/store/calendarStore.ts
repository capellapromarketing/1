"use client";

import { create } from 'zustand';
import { DateTime } from 'luxon';
import type { 
  CalendarView, 
  CalendarEvent, 
  Calendar, 
  Task, 
  ParsedEvent, 
  DailyPlan 
} from '../types/calendar.types';

interface CalendarState {
  currentDate: DateTime;
  selectedDate: DateTime | null;
  view: CalendarView;
  userTimezone: string;
  
  events: CalendarEvent[];
  calendars: Calendar[];
  tasks: Task[];
  
  selectedEvent: CalendarEvent | null;
  isEventPopoverOpen: boolean;
  isCreateModalOpen: boolean;
  
  nlInputValue: string;
  parsedEvent: ParsedEvent | null;
  
  dailyPlan: DailyPlan | null;
  isAIPanelOpen: boolean;
  isAIConsentModalOpen: boolean;
  
  isDragging: boolean;
  draggedEventId: string | null;
  
  sidebarCollapsed: boolean;
  
  undoStack: CalendarEvent[];
}

interface CalendarActions {
  setCurrentDate: (date: DateTime) => void;
  setSelectedDate: (date: DateTime | null) => void;
  setView: (view: CalendarView) => void;
  setUserTimezone: (timezone: string) => void;
  
  goToToday: () => void;
  goToPrevious: () => void;
  goToNext: () => void;
  
  setEvents: (events: CalendarEvent[]) => void;
  addEvent: (event: CalendarEvent) => void;
  updateEvent: (eventId: string, updates: Partial<CalendarEvent>) => void;
  deleteEvent: (eventId: string) => void;
  moveEventToDate: (eventId: string, newStart: DateTime, newEnd: DateTime) => void;
  
  setCalendars: (calendars: Calendar[]) => void;
  toggleCalendarVisibility: (calendarId: string) => void;
  
  setTasks: (tasks: Task[]) => void;
  toggleTaskComplete: (taskId: string) => void;
  convertTaskToEvent: (taskId: string, start: DateTime, end: DateTime) => void;
  
  setSelectedEvent: (event: CalendarEvent | null) => void;
  setIsEventPopoverOpen: (isOpen: boolean) => void;
  setIsCreateModalOpen: (isOpen: boolean) => void;
  
  setNLInputValue: (value: string) => void;
  setParsedEvent: (parsed: ParsedEvent | null) => void;
  
  setDailyPlan: (plan: DailyPlan | null) => void;
  setIsAIPanelOpen: (isOpen: boolean) => void;
  setIsAIConsentModalOpen: (isOpen: boolean) => void;
  
  setIsDragging: (isDragging: boolean) => void;
  setDraggedEventId: (eventId: string | null) => void;
  
  setSidebarCollapsed: (collapsed: boolean) => void;
  
  pushToUndoStack: (event: CalendarEvent) => void;
  popFromUndoStack: () => CalendarEvent | undefined;
  clearUndoStack: () => void;
}

const getInitialTimezone = (): string => {
  if (typeof window !== 'undefined') {
    return Intl.DateTimeFormat().resolvedOptions().timeZone;
  }
  return 'America/New_York';
};

export const useCalendarStore = create<CalendarState & CalendarActions>((set, get) => ({
  currentDate: DateTime.now(),
  selectedDate: null,
  view: 'week',
  userTimezone: getInitialTimezone(),
  
  events: [],
  calendars: [],
  tasks: [],
  
  selectedEvent: null,
  isEventPopoverOpen: false,
  isCreateModalOpen: false,
  
  nlInputValue: '',
  parsedEvent: null,
  
  dailyPlan: null,
  isAIPanelOpen: false,
  isAIConsentModalOpen: false,
  
  isDragging: false,
  draggedEventId: null,
  
  sidebarCollapsed: false,
  
  undoStack: [],
  
  setCurrentDate: (date) => set({ currentDate: date }),
  setSelectedDate: (date) => set({ selectedDate: date }),
  setView: (view) => set({ view }),
  setUserTimezone: (timezone) => set({ userTimezone: timezone }),
  
  goToToday: () => set({ currentDate: DateTime.now() }),
  
  goToPrevious: () => {
    const { view, currentDate } = get();
    const amount = view === 'month' ? { months: 1 } : view === 'week' ? { weeks: 1 } : { days: 1 };
    set({ currentDate: currentDate.minus(amount) });
  },
  
  goToNext: () => {
    const { view, currentDate } = get();
    const amount = view === 'month' ? { months: 1 } : view === 'week' ? { weeks: 1 } : { days: 1 };
    set({ currentDate: currentDate.plus(amount) });
  },
  
  setEvents: (events) => set({ events }),
  
  addEvent: (event) => set((state) => ({ events: [...state.events, event] })),
  
  updateEvent: (eventId, updates) => set((state) => ({
    events: state.events.map((e) => (e.id === eventId ? { ...e, ...updates } : e)),
  })),
  
  deleteEvent: (eventId) => set((state) => {
    const eventToDelete = state.events.find((e) => e.id === eventId);
    return {
      events: state.events.filter((e) => e.id !== eventId),
      undoStack: eventToDelete ? [...state.undoStack, eventToDelete] : state.undoStack,
    };
  }),
  
  moveEventToDate: (eventId, newStart, newEnd) => set((state) => ({
    events: state.events.map((e) => 
      e.id === eventId 
        ? { ...e, startTime: newStart.toISO() || e.startTime, endTime: newEnd.toISO() || e.endTime }
        : e
    ),
  })),
  
  setCalendars: (calendars) => set({ calendars }),
  
  toggleCalendarVisibility: (calendarId) => set((state) => ({
    calendars: state.calendars.map((c) => 
      c.id === calendarId ? { ...c, isVisible: !c.isVisible } : c
    ),
  })),
  
  setTasks: (tasks) => set({ tasks }),
  
  toggleTaskComplete: (taskId) => set((state) => ({
    tasks: state.tasks.map((t) => 
      t.id === taskId ? { ...t, isCompleted: !t.isCompleted } : t
    ),
  })),
  
  convertTaskToEvent: (taskId, start, end) => {
    const { tasks, calendars, userTimezone, addEvent, setTasks } = get();
    const task = tasks.find((t) => t.id === taskId);
    
    if (!task) return;
    
    const defaultCalendar = calendars.find((c) => c.isDefault) || calendars[0];
    
    const newEvent: CalendarEvent = {
      id: `evt-from-task-${Date.now()}`,
      title: task.title,
      startTime: start.toISO() || '',
      endTime: end.toISO() || '',
      timezone: userTimezone,
      isAllDay: false,
      calendarId: defaultCalendar?.id || 'cal-work',
    };
    
    addEvent(newEvent);
    setTasks(tasks.filter((t) => t.id !== taskId));
  },
  
  setSelectedEvent: (event) => set({ selectedEvent: event, isEventPopoverOpen: !!event }),
  setIsEventPopoverOpen: (isOpen) => set({ isEventPopoverOpen: isOpen }),
  setIsCreateModalOpen: (isOpen) => set({ isCreateModalOpen: isOpen }),
  
  setNLInputValue: (value) => set({ nlInputValue: value }),
  setParsedEvent: (parsed) => set({ parsedEvent: parsed }),
  
  setDailyPlan: (plan) => set({ dailyPlan: plan }),
  setIsAIPanelOpen: (isOpen) => set({ isAIPanelOpen: isOpen }),
  setIsAIConsentModalOpen: (isOpen) => set({ isAIConsentModalOpen: isOpen }),
  
  setIsDragging: (isDragging) => set({ isDragging }),
  setDraggedEventId: (eventId) => set({ draggedEventId: eventId }),
  
  setSidebarCollapsed: (collapsed) => set({ sidebarCollapsed: collapsed }),
  
  pushToUndoStack: (event) => set((state) => ({
    undoStack: [...state.undoStack, event],
  })),
  
  popFromUndoStack: () => {
    const { undoStack } = get();
    if (undoStack.length === 0) return undefined;
    const event = undoStack[undoStack.length - 1];
    set({ undoStack: undoStack.slice(0, -1) });
    return event;
  },
  
  clearUndoStack: () => set({ undoStack: [] }),
}));
