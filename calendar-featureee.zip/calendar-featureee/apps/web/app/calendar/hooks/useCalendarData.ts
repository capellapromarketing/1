"use client";

import { useEffect, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { DateTime } from 'luxon';
import { useCalendarStore } from '../store/calendarStore';
import { 
  fetchCalendars, 
  fetchEvents, 
  fetchTasks,
  createEvent as createEventApi,
  updateEvent as updateEventApi,
  deleteEvent as deleteEventApi,
} from '../mocks/fetchers';
import { expandAllRecurringEvents } from '../lib/recurrence';
import type { CalendarEvent, Calendar, Task } from '../types/calendar.types';

export function useCalendarData() {
  const queryClient = useQueryClient();
  const { 
    currentDate, 
    view, 
    userTimezone,
    calendars,
    setCalendars, 
    setEvents, 
    setTasks,
    addEvent: storeAddEvent,
    updateEvent: storeUpdateEvent,
    deleteEvent: storeDeleteEvent,
  } = useCalendarStore();

  const calendarsQuery = useQuery<Calendar[]>({
    queryKey: ['calendars'],
    queryFn: fetchCalendars,
    staleTime: 1000 * 60 * 5,
  });

  const eventsQuery = useQuery<CalendarEvent[]>({
    queryKey: ['events'],
    queryFn: fetchEvents,
    staleTime: 1000 * 60,
  });

  const tasksQuery = useQuery<Task[]>({
    queryKey: ['tasks'],
    queryFn: fetchTasks,
    staleTime: 1000 * 60,
  });

  useEffect(() => {
    if (calendarsQuery.data) {
      setCalendars(calendarsQuery.data);
    }
  }, [calendarsQuery.data, setCalendars]);

  useEffect(() => {
    if (eventsQuery.data) {
      setEvents(eventsQuery.data);
    }
  }, [eventsQuery.data, setEvents]);

  useEffect(() => {
    if (tasksQuery.data) {
      setTasks(tasksQuery.data);
    }
  }, [tasksQuery.data, setTasks]);

  const visibleCalendarIds = useMemo(() => 
    calendars.filter((c) => c.isVisible).map((c) => c.id),
    [calendars]
  );

  const dateRange = useMemo(() => {
    switch (view) {
      case 'month':
        return {
          start: currentDate.startOf('month').startOf('week'),
          end: currentDate.endOf('month').endOf('week'),
        };
      case 'week':
        return {
          start: currentDate.startOf('week'),
          end: currentDate.endOf('week'),
        };
      case 'day':
        return {
          start: currentDate.startOf('day'),
          end: currentDate.endOf('day'),
        };
      case 'agenda':
        return {
          start: currentDate.startOf('day'),
          end: currentDate.plus({ weeks: 2 }).endOf('day'),
        };
      default:
        return {
          start: currentDate.startOf('week'),
          end: currentDate.endOf('week'),
        };
    }
  }, [currentDate, view]);

  const expandedEvents = useMemo(() => {
    const rawEvents = eventsQuery.data || [];
    const visibleEvents = rawEvents.filter((e) => visibleCalendarIds.includes(e.calendarId));
    return expandAllRecurringEvents(visibleEvents, dateRange.start, dateRange.end);
  }, [eventsQuery.data, visibleCalendarIds, dateRange]);

  const createEventMutation = useMutation({
    mutationFn: createEventApi,
    onSuccess: (newEvent) => {
      storeAddEvent(newEvent);
      queryClient.invalidateQueries({ queryKey: ['events'] });
    },
  });

  const updateEventMutation = useMutation({
    mutationFn: ({ eventId, updates }: { eventId: string; updates: Partial<CalendarEvent> }) => 
      updateEventApi(eventId, updates),
    onSuccess: (updatedEvent) => {
      storeUpdateEvent(updatedEvent.id, updatedEvent);
      queryClient.invalidateQueries({ queryKey: ['events'] });
    },
  });

  const deleteEventMutation = useMutation({
    mutationFn: deleteEventApi,
    onSuccess: (_, eventId) => {
      storeDeleteEvent(eventId);
      queryClient.invalidateQueries({ queryKey: ['events'] });
    },
  });

  return {
    events: expandedEvents,
    calendars: calendarsQuery.data || [],
    tasks: tasksQuery.data || [],
    
    isLoading: eventsQuery.isLoading || calendarsQuery.isLoading,
    isError: eventsQuery.isError || calendarsQuery.isError,
    error: eventsQuery.error || calendarsQuery.error,
    
    createEvent: createEventMutation.mutate,
    updateEvent: updateEventMutation.mutate,
    deleteEvent: deleteEventMutation.mutate,
    
    isCreating: createEventMutation.isPending,
    isUpdating: updateEventMutation.isPending,
    isDeleting: deleteEventMutation.isPending,
    
    refetch: () => {
      eventsQuery.refetch();
      calendarsQuery.refetch();
      tasksQuery.refetch();
    },
  };
}
