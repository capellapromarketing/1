"use client";

import { useState, useMemo } from 'react';
import { Globe } from 'lucide-react';
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from '@/components/ui/command';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Button } from '@/components/ui/button';
import { COMMON_TIMEZONES } from '../types/calendar.types';

interface TimezoneSelectorProps {
  value: string;
  onChange: (timezone: string) => void;
}

export function TimezoneSelector({ value, onChange }: TimezoneSelectorProps) {
  const [open, setOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const selectedTimezone = useMemo(() => 
    COMMON_TIMEZONES.find((tz) => tz.value === value),
    [value]
  );

  const filteredTimezones = useMemo(() => {
    if (!searchQuery) return COMMON_TIMEZONES;
    const query = searchQuery.toLowerCase();
    return COMMON_TIMEZONES.filter(
      (tz) => 
        tz.label.toLowerCase().includes(query) || 
        tz.value.toLowerCase().includes(query)
    );
  }, [searchQuery]);

  return (
    <div className="flex items-center gap-4">
      <Globe className="h-4 w-4 text-muted-foreground flex-shrink-0" />
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            role="combobox"
            aria-expanded={open}
            className="justify-start h-9 font-normal flex-1"
            data-testid="button-timezone-selector"
          >
            {selectedTimezone?.label || value || 'Select timezone'}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-[300px] p-0" align="start">
          <Command>
            <CommandInput 
              placeholder="Search timezone..." 
              value={searchQuery}
              onValueChange={setSearchQuery}
            />
            <CommandList>
              <CommandEmpty>No timezone found.</CommandEmpty>
              <CommandGroup>
                {filteredTimezones.map((tz) => (
                  <CommandItem
                    key={tz.value}
                    value={tz.value}
                    onSelect={() => {
                      onChange(tz.value);
                      setOpen(false);
                    }}
                  >
                    <div className="flex flex-col">
                      <span>{tz.label}</span>
                      <span className="text-xs text-muted-foreground">{tz.value}</span>
                    </div>
                  </CommandItem>
                ))}
              </CommandGroup>
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>
    </div>
  );
}
