"use client";

import { useMemo } from 'react';
import { useDraggable } from '@dnd-kit/core';
import { motion } from 'framer-motion';
import { 
  Check, 
  Circle, 
  GripVertical, 
  Plus,
  ChevronDown,
  ChevronRight,
  Calendar as CalendarIcon,
  CheckSquare
} from 'lucide-react';
import { DateTime } from 'luxon';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { useCalendarStore } from '../store/calendarStore';
import { CALENDAR_COLORS, type Task } from '../types/calendar.types';

interface DraggableTaskProps {
  task: Task;
}

function DraggableTask({ task }: DraggableTaskProps) {
  const { toggleTaskComplete } = useCalendarStore();
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({
    id: task.id,
    data: { type: 'task', task },
  });

  const style = transform
    ? {
        transform: `translate3d(${transform.x}px, ${transform.y}px, 0)`,
      }
    : undefined;

  const priorityColors = {
    high: 'text-destructive',
    medium: 'text-orange-500',
    low: 'text-muted-foreground',
  };

  return (
    <motion.div
      ref={setNodeRef}
      style={style}
      className={`
        flex items-center gap-2 p-2 rounded-md group
        ${isDragging ? 'opacity-50 bg-accent shadow-lg' : 'hover:bg-muted'}
        ${task.isCompleted ? 'opacity-60' : ''}
      `}
      whileHover={{ x: 2 }}
      data-testid={`task-item-${task.id}`}
    >
      <div
        {...attributes}
        {...listeners}
        className="cursor-grab opacity-0 group-hover:opacity-100 transition-opacity"
        aria-label="Drag to calendar"
      >
        <GripVertical className="h-4 w-4 text-muted-foreground" />
      </div>

      <Checkbox
        checked={task.isCompleted}
        onCheckedChange={() => toggleTaskComplete(task.id)}
        className="h-4 w-4"
        aria-label={`Mark ${task.title} as ${task.isCompleted ? 'incomplete' : 'complete'}`}
        data-testid={`checkbox-task-${task.id}`}
      />

      <div className="flex-1 min-w-0">
        <p className={`text-sm truncate ${task.isCompleted ? 'line-through' : ''}`}>
          {task.title}
        </p>
        {task.dueDate && (
          <p className="text-xs text-muted-foreground">
            Due {DateTime.fromISO(task.dueDate).toFormat('MMM d')}
          </p>
        )}
      </div>

      {task.priority && (
        <Circle className={`h-2 w-2 fill-current ${priorityColors[task.priority]}`} />
      )}
    </motion.div>
  );
}

export function SidebarCalendarsList() {
  const { calendars, tasks, toggleCalendarVisibility } = useCalendarStore();

  const incompleteTasks = useMemo(
    () => tasks.filter((task) => !task.isCompleted),
    [tasks]
  );

  const completedTasks = useMemo(
    () => tasks.filter((task) => task.isCompleted),
    [tasks]
  );

  const getCalendarColor = (colorName: string) => {
    const color = CALENDAR_COLORS.find((c) => c.id === colorName);
    return color?.hex || '#8E8E93';
  };

  return (
    <div className="flex flex-col gap-4 p-3">
      <Collapsible defaultOpen>
        <CollapsibleTrigger className="flex items-center gap-2 w-full p-2 rounded-md hover:bg-muted">
          <CalendarIcon className="h-4 w-4 text-muted-foreground" />
          <span className="flex-1 text-sm font-medium text-left">Calendars</span>
          <ChevronDown className="h-4 w-4 text-muted-foreground transition-transform duration-200 group-data-[state=closed]:rotate-[-90deg]" />
        </CollapsibleTrigger>
        <CollapsibleContent>
          <div className="mt-1 space-y-1">
            {calendars.map((calendar) => (
              <label
                key={calendar.id}
                className="flex items-center gap-2 p-2 rounded-md cursor-pointer hover:bg-muted"
                data-testid={`calendar-toggle-${calendar.id}`}
              >
                <Checkbox
                  checked={calendar.isVisible}
                  onCheckedChange={() => toggleCalendarVisibility(calendar.id)}
                  className="h-4 w-4"
                  style={{
                    borderColor: getCalendarColor(calendar.color),
                    backgroundColor: calendar.isVisible ? getCalendarColor(calendar.color) : 'transparent',
                  }}
                  aria-label={`Toggle ${calendar.name} visibility`}
                />
                <span className="text-sm">{calendar.name}</span>
                {calendar.isDefault && (
                  <Badge variant="secondary" className="text-xs ml-auto">
                    Default
                  </Badge>
                )}
              </label>
            ))}
          </div>
        </CollapsibleContent>
      </Collapsible>

      <Collapsible defaultOpen>
        <CollapsibleTrigger className="flex items-center gap-2 w-full p-2 rounded-md hover:bg-muted">
          <CheckSquare className="h-4 w-4 text-muted-foreground" />
          <span className="flex-1 text-sm font-medium text-left">Tasks</span>
          <Badge variant="secondary" className="text-xs">
            {incompleteTasks.length}
          </Badge>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <div className="mt-1 space-y-1">
            {incompleteTasks.length === 0 ? (
              <p className="text-sm text-muted-foreground p-2">No pending tasks</p>
            ) : (
              incompleteTasks.map((task) => (
                <DraggableTask key={task.id} task={task} />
              ))
            )}

            {completedTasks.length > 0 && (
              <Collapsible>
                <CollapsibleTrigger className="flex items-center gap-2 w-full p-2 text-xs text-muted-foreground hover:text-foreground">
                  <ChevronRight className="h-3 w-3 transition-transform duration-200 data-[state=open]:rotate-90" />
                  Completed ({completedTasks.length})
                </CollapsibleTrigger>
                <CollapsibleContent>
                  <div className="space-y-1">
                    {completedTasks.map((task) => (
                      <DraggableTask key={task.id} task={task} />
                    ))}
                  </div>
                </CollapsibleContent>
              </Collapsible>
            )}
          </div>
        </CollapsibleContent>
      </Collapsible>
    </div>
  );
}
