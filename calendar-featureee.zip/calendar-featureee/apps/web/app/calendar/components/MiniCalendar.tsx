"use client";

import { useMemo } from 'react';
import { motion } from 'framer-motion';
import { DateTime } from 'luxon';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCalendarStore } from '../store/calendarStore';
import { getMonthDays, isToday, isCurrentMonth } from '../lib/dateUtils';

const WEEKDAY_LABELS = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];

export function MiniCalendar() {
  const { currentDate, setCurrentDate, selectedDate, setSelectedDate } = useCalendarStore();

  const monthDays = useMemo(() => getMonthDays(currentDate), [currentDate]);

  const handlePrevMonth = () => {
    setCurrentDate(currentDate.minus({ months: 1 }));
  };

  const handleNextMonth = () => {
    setCurrentDate(currentDate.plus({ months: 1 }));
  };

  const handleDayClick = (day: DateTime) => {
    setSelectedDate(day);
    setCurrentDate(day);
  };

  return (
    <div className="p-3" data-testid="mini-calendar">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold">
          {currentDate.toFormat('MMMM yyyy')}
        </h3>
        <div className="flex gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6"
            onClick={handlePrevMonth}
            aria-label="Previous month"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6"
            onClick={handleNextMonth}
            aria-label="Next month"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-0.5 mb-1">
        {WEEKDAY_LABELS.map((day, index) => (
          <div
            key={index}
            className="text-center text-xs text-muted-foreground font-medium py-1"
          >
            {day}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-7 gap-0.5">
        {monthDays.map((day, index) => {
          const isTodayDate = isToday(day);
          const isCurrentMonthDay = isCurrentMonth(day, currentDate);
          const isSelected = selectedDate?.hasSame(day, 'day');

          return (
            <motion.button
              key={index}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => handleDayClick(day)}
              className={`
                h-7 w-7 text-xs rounded-full flex items-center justify-center
                transition-colors
                ${!isCurrentMonthDay ? 'text-muted-foreground/50' : ''}
                ${isTodayDate && !isSelected ? 'bg-primary/10 text-primary font-bold' : ''}
                ${isSelected ? 'bg-primary text-primary-foreground font-bold' : ''}
                ${!isTodayDate && !isSelected ? 'hover:bg-muted' : ''}
              `}
              aria-label={day.toFormat('MMMM d, yyyy')}
              data-testid={`mini-cal-day-${day.toISODate()}`}
            >
              {day.day}
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}
