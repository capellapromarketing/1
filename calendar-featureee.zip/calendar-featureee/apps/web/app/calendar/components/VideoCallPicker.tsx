"use client";

import { useState } from 'react';
import { Video, Plus, X, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { VIDEO_PROVIDERS, type VideoCallInfo } from '../types/calendar.types';

interface VideoCallPickerProps {
  value?: VideoCallInfo;
  onChange: (value: VideoCallInfo | undefined) => void;
}

export function VideoCallPicker({ value, onChange }: VideoCallPickerProps) {
  const [isAdding, setIsAdding] = useState(!!value);
  const [provider, setProvider] = useState<VideoCallInfo['provider']>(value?.provider || 'zoom');
  const [link, setLink] = useState(value?.link || '');

  const handleAdd = () => {
    setIsAdding(true);
  };

  const handleRemove = () => {
    setIsAdding(false);
    setProvider('zoom');
    setLink('');
    onChange(undefined);
  };

  const handleSave = () => {
    if (link.trim()) {
      onChange({ provider, link: link.trim() });
    }
  };

  const handleLinkChange = (newLink: string) => {
    setLink(newLink);
    if (newLink.trim()) {
      onChange({ provider, link: newLink.trim() });
    }
  };

  const handleProviderChange = (newProvider: VideoCallInfo['provider']) => {
    setProvider(newProvider);
    if (link.trim()) {
      onChange({ provider: newProvider, link: link.trim() });
    }
  };

  if (!isAdding) {
    return (
      <Button
        type="button"
        variant="ghost"
        className="justify-start gap-2 text-muted-foreground"
        onClick={handleAdd}
        data-testid="button-add-video-call"
      >
        <Video className="h-4 w-4" />
        Add video conferencing
      </Button>
    );
  }

  return (
    <div className="space-y-3" data-testid="video-call-picker">
      <div className="flex items-center justify-between">
        <Label className="flex items-center gap-2">
          <Video className="h-4 w-4" />
          Video Call
        </Label>
        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="h-6 w-6"
          onClick={handleRemove}
          aria-label="Remove video call"
        >
          <X className="h-4 w-4" />
        </Button>
      </div>

      <div className="flex gap-2">
        <Select value={provider} onValueChange={(v) => handleProviderChange(v as VideoCallInfo['provider'])}>
          <SelectTrigger className="w-[140px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {VIDEO_PROVIDERS.map((p) => (
              <SelectItem key={p.id} value={p.id}>
                {p.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Input
          type="url"
          placeholder="Paste meeting link"
          value={link}
          onChange={(e) => handleLinkChange(e.target.value)}
          className="flex-1"
          data-testid="input-video-link"
        />
      </div>

      {value?.link && (
        <a
          href={value.link}
          target="_blank"
          rel="noopener noreferrer"
          className="text-sm text-primary hover:underline flex items-center gap-1"
        >
          Open {VIDEO_PROVIDERS.find((p) => p.id === value.provider)?.name} link
          <ExternalLink className="h-3 w-3" />
        </a>
      )}
    </div>
  );
}
