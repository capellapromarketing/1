"use client";

import { 
  DndContext, 
  MouseSensor, 
  TouchSensor, 
  useSensor, 
  useSensors,
  closestCenter,
} from '@dnd-kit/core';
import { motion, AnimatePresence } from 'framer-motion';
import { useCalendarStore } from '../store/calendarStore';
import { useCalendarData } from '../hooks/useCalendarData';
import { useDragEvents } from '../hooks/useDragEvents';
import { CalendarHeader } from './CalendarHeader';
import { CalendarSidebar } from './CalendarSidebar';
import { MonthView } from './MonthView';
import { WeekView } from './WeekView';
import { DayView } from './DayView';
import { AgendaView } from './AgendaView';
import { CreateEventModal } from './CreateEventModal';
import { EventPopover } from './EventPopover';
import { AIPlannerPanel } from './AIPlannerPanel';
import { AIConsentModal } from './AIConsentModal';
import { DragLayer } from './DragLayer';
import { UndoToastContainer } from './UndoToast';

export function CalendarPage() {
  const { view } = useCalendarStore();
  const { isError, error } = useCalendarData();
  const {
    handleDragStart,
    handleDragMove,
    handleDragEnd,
    handleDragCancel,
  } = useDragEvents();

  const mouseSensor = useSensor(MouseSensor, {
    activationConstraint: {
      distance: 10,
    },
  });

  const touchSensor = useSensor(TouchSensor, {
    activationConstraint: {
      delay: 250,
      tolerance: 5,
    },
  });

  const sensors = useSensors(mouseSensor, touchSensor);

  const renderView = () => {
    switch (view) {
      case 'month':
        return <MonthView />;
      case 'week':
        return <WeekView />;
      case 'day':
        return <DayView />;
      case 'agenda':
        return <AgendaView />;
      default:
        return <WeekView />;
    }
  };

  if (isError) {
    return (
      <div className="flex items-center justify-center h-screen bg-background">
        <div className="text-center p-8">
          <h2 className="text-xl font-semibold text-destructive mb-2">
            Failed to load calendar
          </h2>
          <p className="text-muted-foreground mb-4">
            {error instanceof Error ? error.message : 'An unexpected error occurred'}
          </p>
          <button
            onClick={() => window.location.reload()}
            className="px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={closestCenter}
      onDragStart={handleDragStart}
      onDragMove={handleDragMove}
      onDragEnd={handleDragEnd}
      onDragCancel={handleDragCancel}
    >
      <div 
        className="flex flex-col h-screen bg-background"
        data-testid="calendar-page"
      >
        <CalendarHeader />
        
        <div className="flex flex-1 overflow-hidden">
          <CalendarSidebar />
          
          <main className="flex-1 overflow-hidden">
            <AnimatePresence mode="wait">
              <motion.div
                key={view}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
                className="h-full"
              >
                {renderView()}
              </motion.div>
            </AnimatePresence>
          </main>

          <AIPlannerPanel />
        </div>

        <CreateEventModal />
        <EventPopover />
        <AIConsentModal />
        <UndoToastContainer />

        <DragLayer />
      </div>
    </DndContext>
  );
}
