"use client";

import { useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useDraggable } from '@dnd-kit/core';
import { CSS } from '@dnd-kit/utilities';
import { 
  ChevronLeft, 
  ChevronRight, 
  Plus, 
  Check, 
  Circle, 
  Clock,
  Flag
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { useCalendarStore } from '../store/calendarStore';
import { MiniCalendar } from './MiniCalendar';
import { CALENDAR_COLORS, type Task } from '../types/calendar.types';
import { cn } from '@/lib/utils';

interface TaskItemProps {
  task: Task;
}

function TaskItem({ task }: TaskItemProps) {
  const { toggleTaskComplete } = useCalendarStore();

  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    isDragging,
  } = useDraggable({
    id: task.id,
    data: { task, type: 'task' },
  });

  const style = {
    transform: CSS.Translate.toString(transform),
    opacity: isDragging ? 0.5 : 1,
  };

  const priorityColors = {
    low: 'text-muted-foreground',
    medium: 'text-yellow-500',
    high: 'text-destructive',
  };

  return (
    <motion.div
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      whileHover={{ x: 2 }}
      className={cn(
        'flex items-start gap-2 p-2 rounded-md cursor-grab active:cursor-grabbing',
        'hover:bg-muted/50 transition-colors',
        task.completed && 'opacity-50'
      )}
      data-testid={`task-${task.id}`}
    >
      <Checkbox
        checked={task.completed}
        onCheckedChange={() => toggleTaskComplete(task.id)}
        className="mt-0.5"
        onClick={(e) => e.stopPropagation()}
      />
      <div className="flex-1 min-w-0">
        <p className={cn(
          'text-sm truncate',
          task.completed && 'line-through text-muted-foreground'
        )}>
          {task.title}
        </p>
        <div className="flex items-center gap-2 mt-0.5">
          {task.dueDate && (
            <span className="text-xs text-muted-foreground flex items-center gap-1">
              <Clock className="h-3 w-3" />
              {task.dueDate}
            </span>
          )}
          {task.estimatedMinutes && (
            <span className="text-xs text-muted-foreground">
              {task.estimatedMinutes}m
            </span>
          )}
        </div>
      </div>
      <Flag className={cn('h-3.5 w-3.5 flex-shrink-0', priorityColors[task.priority])} />
    </motion.div>
  );
}

export function CalendarSidebar() {
  const { 
    calendars, 
    tasks,
    toggleCalendarVisibility,
    setIsCreateModalOpen,
    sidebarCollapsed,
    setSidebarCollapsed,
  } = useCalendarStore();

  const incompleteTasks = useMemo(() => 
    tasks.filter((t) => !t.completed),
    [tasks]
  );

  const completedTasks = useMemo(() => 
    tasks.filter((t) => t.completed),
    [tasks]
  );

  if (sidebarCollapsed) {
    return (
      <div className="w-12 border-r flex flex-col items-center py-4 bg-muted/30">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setSidebarCollapsed(false)}
          aria-label="Expand sidebar"
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ width: 0, opacity: 0 }}
      animate={{ width: 280, opacity: 1 }}
      exit={{ width: 0, opacity: 0 }}
      className="border-r bg-muted/30 flex flex-col h-full"
      data-testid="calendar-sidebar"
    >
      <div className="flex items-center justify-between p-3 border-b">
        <Button
          onClick={() => setIsCreateModalOpen(true)}
          size="sm"
          className="flex-1 gap-2"
          data-testid="button-create-event-sidebar"
        >
          <Plus className="h-4 w-4" />
          Create
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="ml-2"
          onClick={() => setSidebarCollapsed(true)}
          aria-label="Collapse sidebar"
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>
      </div>

      <ScrollArea className="flex-1">
        <MiniCalendar />

        <Separator />

        <div className="p-3">
          <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
            My Calendars
          </h4>
          <div className="space-y-1">
            {calendars.map((calendar) => {
              const color = CALENDAR_COLORS.find((c) => c.id === calendar.color);
              return (
                <button
                  key={calendar.id}
                  onClick={() => toggleCalendarVisibility(calendar.id)}
                  className={cn(
                    'flex items-center gap-2 w-full px-2 py-1.5 rounded-md text-sm',
                    'hover:bg-muted transition-colors',
                    !calendar.isVisible && 'opacity-50'
                  )}
                  data-testid={`calendar-toggle-${calendar.id}`}
                >
                  <div
                    className="w-3 h-3 rounded-sm flex items-center justify-center"
                    style={{ backgroundColor: color?.hex || '#8E8E93' }}
                  >
                    {calendar.isVisible && (
                      <Check className="h-2 w-2 text-white" />
                    )}
                  </div>
                  <span className="truncate">{calendar.name}</span>
                </button>
              );
            })}
          </div>
        </div>

        <Separator />

        <div className="p-3">
          <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
            Tasks ({incompleteTasks.length})
          </h4>
          <div className="space-y-1">
            <AnimatePresence>
              {incompleteTasks.map((task) => (
                <TaskItem key={task.id} task={task} />
              ))}
            </AnimatePresence>
          </div>

          {completedTasks.length > 0 && (
            <>
              <h5 className="text-xs text-muted-foreground mt-4 mb-2">
                Completed ({completedTasks.length})
              </h5>
              <div className="space-y-1">
                <AnimatePresence>
                  {completedTasks.slice(0, 3).map((task) => (
                    <TaskItem key={task.id} task={task} />
                  ))}
                </AnimatePresence>
              </div>
            </>
          )}
        </div>
      </ScrollArea>
    </motion.div>
  );
}
