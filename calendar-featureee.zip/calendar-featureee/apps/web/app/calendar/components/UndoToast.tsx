"use client";

import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Undo2, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCalendarStore } from '../store/calendarStore';

interface UndoToastProps {
  message: string;
  duration?: number;
  onUndo: () => void;
  onDismiss: () => void;
}

export function UndoToast({ 
  message, 
  duration = 5000, 
  onUndo, 
  onDismiss 
}: UndoToastProps) {
  const [isVisible, setIsVisible] = useState(true);
  const [progress, setProgress] = useState(100);

  useEffect(() => {
    const startTime = Date.now();
    const endTime = startTime + duration;

    const interval = setInterval(() => {
      const now = Date.now();
      const remaining = Math.max(0, endTime - now);
      const newProgress = (remaining / duration) * 100;
      setProgress(newProgress);

      if (remaining <= 0) {
        clearInterval(interval);
        setIsVisible(false);
        setTimeout(onDismiss, 200);
      }
    }, 50);

    return () => clearInterval(interval);
  }, [duration, onDismiss]);

  const handleUndo = () => {
    onUndo();
    setIsVisible(false);
    setTimeout(onDismiss, 200);
  };

  const handleDismiss = () => {
    setIsVisible(false);
    setTimeout(onDismiss, 200);
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: 50, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 50, scale: 0.95 }}
          transition={{ duration: 0.2 }}
          className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50"
          role="alert"
          aria-live="polite"
          data-testid="undo-toast"
        >
          <div className="relative bg-foreground text-background rounded-lg shadow-xl overflow-hidden min-w-[300px]">
            <div className="flex items-center gap-3 px-4 py-3">
              <Undo2 className="h-4 w-4 flex-shrink-0" />
              <span className="text-sm flex-1">{message}</span>
              <Button
                variant="ghost"
                size="sm"
                className="h-7 text-background hover:bg-white/10 hover:text-background"
                onClick={handleUndo}
                data-testid="button-undo"
              >
                Undo
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7 text-background/70 hover:bg-white/10 hover:text-background"
                onClick={handleDismiss}
                aria-label="Dismiss"
                data-testid="button-dismiss-toast"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
            
            <div className="h-0.5 bg-white/20">
              <motion.div
                className="h-full bg-primary"
                initial={{ width: '100%' }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.05, ease: 'linear' }}
              />
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export function UndoToastContainer() {
  const { undoStack, popFromUndoStack, addEvent } = useCalendarStore();
  const [toast, setToast] = useState<{ id: string; message: string } | null>(null);

  useEffect(() => {
    if (undoStack.length > 0 && !toast) {
      const lastEvent = undoStack[undoStack.length - 1];
      setToast({
        id: lastEvent.id,
        message: `Event "${lastEvent.title}" deleted`,
      });
    }
  }, [undoStack, toast]);

  const handleUndo = () => {
    const event = popFromUndoStack();
    if (event) {
      addEvent(event);
    }
    setToast(null);
  };

  const handleDismiss = () => {
    setToast(null);
  };

  if (!toast) return null;

  return (
    <UndoToast
      key={toast.id}
      message={toast.message}
      onUndo={handleUndo}
      onDismiss={handleDismiss}
    />
  );
}
