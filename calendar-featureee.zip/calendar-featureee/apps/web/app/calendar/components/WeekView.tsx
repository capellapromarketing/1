"use client";

import { useMemo, useRef } from 'react';
import { useDroppable } from '@dnd-kit/core';
import { motion } from 'framer-motion';
import { DateTime } from 'luxon';
import { useCalendarStore } from '../store/calendarStore';
import { useCalendarData } from '../hooks/useCalendarData';
import { 
  getWeekDays, 
  isToday, 
  getEventsForDate,
  getEventPositionInDay,
  getTimeSlots,
  calculateTravelBuffer,
  getOverlappingEvents,
} from '../lib/dateUtils';
import { EventPill } from './EventPill';
import { CALENDAR_COLORS, type CalendarEvent } from '../types/calendar.types';

const HOUR_HEIGHT = 60;
const TIME_SLOTS = getTimeSlots(60);

interface TimeGridCellProps {
  date: DateTime;
  hour: number;
}

function TimeGridCell({ date, hour }: TimeGridCellProps) {
  const dateKey = date.toISODate() || '';
  const cellId = `week-cell-${dateKey}-${hour}`;

  const { setNodeRef, isOver } = useDroppable({
    id: cellId,
    data: { date, hour, minute: 0, type: 'time-cell' },
  });

  return (
    <div
      ref={setNodeRef}
      className={`
        h-[60px] border-b border-r relative
        ${isOver ? 'bg-primary/10' : 'hover:bg-muted/30'}
      `}
      data-testid={cellId}
    >
      <div className="absolute left-0 top-1/4 w-full h-px bg-border/20" />
      <div className="absolute left-0 top-1/2 w-full h-px bg-border/30" />
      <div className="absolute left-0 top-3/4 w-full h-px bg-border/20" />
    </div>
  );
}

interface DayColumnProps {
  date: DateTime;
  events: CalendarEvent[];
  overlappingPositions: Map<string, { column: number; totalColumns: number }>;
}

function DayColumn({ date, events, overlappingPositions }: DayColumnProps) {
  const { userTimezone, calendars } = useCalendarStore();
  const isTodayDate = isToday(date);

  const allDayEvents = useMemo(() => events.filter((e) => e.isAllDay), [events]);
  const timedEvents = useMemo(() => events.filter((e) => !e.isAllDay), [events]);

  const getCalendarColor = (calendarId: string) => {
    const calendar = calendars.find((c) => c.id === calendarId);
    const color = CALENDAR_COLORS.find((c) => c.id === calendar?.color);
    return color?.hex || '#8E8E93';
  };

  return (
    <div className="flex-1 relative min-w-[120px]" data-testid={`week-day-${date.toISODate()}`}>
      <div
        className={`
          sticky top-0 z-10 bg-background border-b px-2 py-3 text-center
          ${isTodayDate ? 'bg-primary/5' : ''}
        `}
      >
        <div className="text-xs text-muted-foreground">{date.toFormat('EEE')}</div>
        <div
          className={`
            text-lg font-bold mt-1 w-8 h-8 mx-auto flex items-center justify-center rounded-full
            ${isTodayDate ? 'bg-primary text-primary-foreground' : ''}
          `}
        >
          {date.day}
        </div>
      </div>

      {allDayEvents.length > 0 && (
        <div className="border-b bg-muted/20 px-1 py-1 space-y-0.5 max-h-[80px] overflow-y-auto">
          {allDayEvents.map((event) => (
            <EventPill key={event.id} event={event} compact showTime={false} />
          ))}
        </div>
      )}

      <div className="relative">
        {TIME_SLOTS.map((slot) => (
          <TimeGridCell key={slot.hour} date={date} hour={slot.hour} />
        ))}

        {timedEvents.map((event) => {
          const { top, height } = getEventPositionInDay(event, userTimezone, HOUR_HEIGHT);
          const color = getCalendarColor(event.calendarId);
          const travelBuffer = calculateTravelBuffer(event);
          const position = overlappingPositions.get(event.id);
          
          const width = position ? `${100 / position.totalColumns}%` : '100%';
          const left = position ? `${(position.column / position.totalColumns) * 100}%` : '0';

          return (
            <div key={event.id}>
              {travelBuffer && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="absolute rounded-md flex items-center px-1"
                  style={{
                    top: `${(travelBuffer.bufferStart.hour * 60 + travelBuffer.bufferStart.minute) / 60 * HOUR_HEIGHT}px`,
                    height: `${event.travelTime!.minutes}px`,
                    left: '2px',
                    right: '2px',
                    backgroundColor: `${color}15`,
                    borderLeft: `2px dashed ${color}50`,
                  }}
                >
                  <span className="text-xs text-muted-foreground truncate">
                    Travel
                  </span>
                </motion.div>
              )}

              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="absolute px-0.5"
                style={{ 
                  top: `${top}px`, 
                  height: `${Math.max(height, 24)}px`,
                  left,
                  width,
                }}
              >
                <div 
                  className="h-full rounded-md overflow-hidden"
                  style={{ backgroundColor: `${color}10` }}
                >
                  <EventPill
                    event={event}
                    showTime
                    className="h-full text-xs"
                  />
                </div>
              </motion.div>
            </div>
          );
        })}

        {isTodayDate && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="absolute left-0 right-0 h-0.5 bg-destructive z-20 pointer-events-none"
            style={{
              top: `${(DateTime.now().hour * 60 + DateTime.now().minute) / 60 * HOUR_HEIGHT}px`,
            }}
          >
            <div className="absolute -left-1 -top-1 w-2.5 h-2.5 rounded-full bg-destructive" />
          </motion.div>
        )}
      </div>
    </div>
  );
}

export function WeekView() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { currentDate, userTimezone } = useCalendarStore();
  const { events, isLoading } = useCalendarData();

  const weekDays = useMemo(() => getWeekDays(currentDate), [currentDate]);

  const eventsPerDay = useMemo(() => {
    const map = new Map<string, CalendarEvent[]>();
    weekDays.forEach((day) => {
      const dateKey = day.toISODate();
      if (dateKey) {
        map.set(dateKey, getEventsForDate(events, day, userTimezone));
      }
    });
    return map;
  }, [events, weekDays, userTimezone]);

  const overlappingPositions = useMemo(() => {
    const allPositions = new Map<string, { column: number; totalColumns: number }>();
    weekDays.forEach((day) => {
      const dateKey = day.toISODate();
      if (dateKey) {
        const dayEvents = eventsPerDay.get(dateKey) || [];
        const timedEvents = dayEvents.filter((e) => !e.isAllDay);
        const positions = getOverlappingEvents(timedEvents, userTimezone);
        positions.forEach((pos, id) => allPositions.set(id, pos));
      }
    });
    return allPositions;
  }, [eventsPerDay, weekDays, userTimezone]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="h-8 w-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div ref={containerRef} className="flex h-full overflow-auto" data-testid="week-view">
      <div className="sticky left-0 z-20 bg-background border-r w-16 flex-shrink-0">
        <div className="h-[68px] border-b" />
        <div className="relative">
          {TIME_SLOTS.map((slot) => (
            <div
              key={slot.hour}
              className="h-[60px] px-2 text-right text-xs text-muted-foreground relative flex items-start"
            >
              <span className="absolute -top-2 right-2">{slot.label}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="flex flex-1">
        {weekDays.map((day) => {
          const dateKey = day.toISODate() || '';
          const dayEvents = eventsPerDay.get(dateKey) || [];

          return (
            <DayColumn
              key={dateKey}
              date={day}
              events={dayEvents}
              overlappingPositions={overlappingPositions}
            />
          );
        })}
      </div>
    </div>
  );
}
