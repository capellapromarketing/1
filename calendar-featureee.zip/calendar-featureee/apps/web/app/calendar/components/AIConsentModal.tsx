"use client";

import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Shield, Clock, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCalendarStore } from '../store/calendarStore';
import { useDailyPlanner } from '../hooks/useDailyPlanner';

export function AIConsentModal() {
  const { isAIConsentModalOpen } = useCalendarStore();
  const { handleAcceptConsent, handleDeclineConsent } = useDailyPlanner();

  return (
    <AnimatePresence>
      {isAIConsentModalOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.15 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
        >
          <div 
            className="absolute inset-0 bg-black/50" 
            onClick={handleDeclineConsent}
            aria-hidden="true"
          />
          
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="relative bg-background rounded-lg shadow-xl w-full max-w-md overflow-hidden"
            role="dialog"
            aria-modal="true"
            aria-labelledby="ai-consent-title"
            data-testid="ai-consent-modal"
          >
            <div className="p-6">
              <div className="flex items-center justify-center w-12 h-12 mx-auto mb-4 bg-primary/10 rounded-full">
                <Sparkles className="h-6 w-6 text-primary" />
              </div>

              <h2 id="ai-consent-title" className="text-xl font-semibold text-center mb-2">
                Enable AI Daily Planning
              </h2>
              
              <p className="text-muted-foreground text-center mb-6">
                Our AI assistant can analyze your schedule and suggest optimizations to help you be more productive.
              </p>

              <div className="space-y-4 mb-6">
                <div className="flex items-start gap-3">
                  <div className="p-2 bg-muted rounded-lg">
                    <Shield className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <div>
                    <h3 className="font-medium text-sm">Your data is secure</h3>
                    <p className="text-sm text-muted-foreground">
                      We only analyze your calendar data to provide suggestions. Your information is never shared.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="p-2 bg-muted rounded-lg">
                    <Clock className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <div>
                    <h3 className="font-medium text-sm">Smart scheduling</h3>
                    <p className="text-sm text-muted-foreground">
                      Get suggestions for focus time, breaks, and meeting preparation based on your habits.
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={handleDeclineConsent}
                  data-testid="button-decline-consent"
                >
                  Not Now
                </Button>
                <Button
                  className="flex-1"
                  onClick={handleAcceptConsent}
                  data-testid="button-accept-consent"
                >
                  Enable AI Planning
                </Button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
