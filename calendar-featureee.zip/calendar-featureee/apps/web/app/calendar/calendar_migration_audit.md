# Calendar Migration Audit

## Overview

This document details the migration of the Calendar application from the Vite/Express architecture (`client/src/calendar/`) to the Next.js App Router structure (`apps/web/app/calendar/`).

**Migration Date:** November 29, 2025  
**Source:** `client/src/calendar/`  
**Target:** `apps/web/app/calendar/`

---

## Technology Stack (Preserved)

| Technology | Version | Purpose |
|------------|---------|---------|
| React | 18.x | UI Framework |
| Next.js App Router | 14+ | Framework & Routing |
| Zustand | 4.x | State Management |
| TanStack Query | 5.x | Data Fetching & Caching |
| @dnd-kit/core | 6.x | Drag-and-Drop |
| Luxon | 3.x | Date/Time Handling |
| rrule.js | 2.x | Recurrence Rules |
| react-hook-form | 7.x | Form Management |
| Zod | 3.x | Schema Validation |
| Framer Motion | 10+ | Animations |
| Tailwind CSS | 3.x | Styling |
| shadcn/ui | Latest | UI Components |

---

## File Migration Map

### Types
| Source | Target |
|--------|--------|
| `client/src/calendar/types/calendar.types.ts` | `apps/web/app/calendar/types/calendar.types.ts` |

### Store
| Source | Target |
|--------|--------|
| `client/src/calendar/store/calendarStore.ts` | `apps/web/app/calendar/store/calendarStore.ts` |

### Library Utilities
| Source | Target |
|--------|--------|
| `client/src/calendar/lib/dateUtils.ts` | `apps/web/app/calendar/lib/dateUtils.ts` |
| `client/src/calendar/lib/recurrence.ts` | `apps/web/app/calendar/lib/recurrence.ts` |

### Mock Data & Fetchers
| Source | Target |
|--------|--------|
| (API routes in server) | `apps/web/app/calendar/mock-data/calendar.mock.json` |
| (Various API calls) | `apps/web/app/calendar/mocks/fetchers.ts` |

### Hooks
| Source | Target |
|--------|--------|
| `client/src/calendar/hooks/useCalendarData.ts` | `apps/web/app/calendar/hooks/useCalendarData.ts` |
| `client/src/calendar/hooks/useNLPInput.ts` | `apps/web/app/calendar/hooks/useNLPInput.ts` |
| `client/src/calendar/hooks/useDragEvents.ts` | `apps/web/app/calendar/hooks/useDragEvents.ts` |
| `client/src/calendar/hooks/useDailyPlanner.ts` | `apps/web/app/calendar/hooks/useDailyPlanner.ts` |
| `client/src/calendar/hooks/useRecurrence.ts` | `apps/web/app/calendar/hooks/useRecurrence.ts` |
| `client/src/calendar/hooks/index.ts` | `apps/web/app/calendar/hooks/index.ts` |

### Components
| Source | Target |
|--------|--------|
| `client/src/calendar/components/EventPill.tsx` | `apps/web/app/calendar/components/EventPill.tsx` |
| `client/src/calendar/components/MiniCalendar.tsx` | `apps/web/app/calendar/components/MiniCalendar.tsx` |
| `client/src/calendar/components/CalendarSidebar.tsx` | `apps/web/app/calendar/components/CalendarSidebar.tsx` |
| `client/src/calendar/components/CalendarHeader.tsx` | `apps/web/app/calendar/components/CalendarHeader.tsx` |
| `client/src/calendar/components/NLPInput.tsx` | `apps/web/app/calendar/components/NLPInput.tsx` |
| `client/src/calendar/components/TimezoneSelector.tsx` | `apps/web/app/calendar/components/TimezoneSelector.tsx` |
| `client/src/calendar/components/VideoCallPicker.tsx` | `apps/web/app/calendar/components/VideoCallPicker.tsx` |
| `client/src/calendar/components/TravelTimeField.tsx` | `apps/web/app/calendar/components/TravelTimeField.tsx` |
| `client/src/calendar/components/RecurringEventOptions.tsx` | `apps/web/app/calendar/components/RecurringEventOptions.tsx` |
| `client/src/calendar/components/MonthView.tsx` | `apps/web/app/calendar/components/MonthView.tsx` |
| `client/src/calendar/components/WeekView.tsx` | `apps/web/app/calendar/components/WeekView.tsx` |
| `client/src/calendar/components/DayView.tsx` | `apps/web/app/calendar/components/DayView.tsx` |
| `client/src/calendar/components/AgendaView.tsx` | `apps/web/app/calendar/components/AgendaView.tsx` |
| `client/src/calendar/components/CreateEventModal.tsx` | `apps/web/app/calendar/components/CreateEventModal.tsx` |
| `client/src/calendar/components/EventPopover.tsx` | `apps/web/app/calendar/components/EventPopover.tsx` |
| `client/src/calendar/components/AIPlannerPanel.tsx` | `apps/web/app/calendar/components/AIPlannerPanel.tsx` |
| `client/src/calendar/components/AIConsentModal.tsx` | `apps/web/app/calendar/components/AIConsentModal.tsx` |
| `client/src/calendar/components/DragLayer.tsx` | `apps/web/app/calendar/components/DragLayer.tsx` |
| `client/src/calendar/components/UndoToast.tsx` | `apps/web/app/calendar/components/UndoToast.tsx` |
| `client/src/calendar/components/SidebarCalendarsList.tsx` | `apps/web/app/calendar/components/SidebarCalendarsList.tsx` |
| `client/src/calendar/pages/CalendarPage.tsx` | `apps/web/app/calendar/components/CalendarPage.tsx` |
| (N/A - New) | `apps/web/app/calendar/components/index.ts` |

### Entry Points
| Source | Target |
|--------|--------|
| `client/src/calendar/pages/CalendarPage.tsx` | `apps/web/app/calendar/page.tsx` |
| (N/A - New) | `apps/web/app/calendar/layout.tsx` |

---

## Key Changes for Next.js App Router

### 1. "use client" Directive
All interactive components, hooks, and the store now include the `"use client"` directive at the top of each file to ensure they run on the client side in Next.js App Router.

### 2. Import Path Updates
- Components use `@/components/ui/` path alias for shadcn/ui components
- Internal imports use relative paths within the calendar module
- `@/lib/utils` for shared utilities (e.g., `cn` function)

### 3. Server-Safe Initialization
The Zustand store includes SSR-safe timezone detection:
```typescript
const getInitialTimezone = (): string => {
  if (typeof window !== 'undefined') {
    return Intl.DateTimeFormat().resolvedOptions().timeZone;
  }
  return 'America/New_York';
};
```

### 4. QueryClient Provider
The `page.tsx` wraps the CalendarPage with `QueryClientProvider` using a client-side state pattern for Next.js compatibility:
```typescript
const [queryClient] = useState(() => new QueryClient({...}));
```

### 5. Mock Data Architecture
- Backend API routes replaced with mock fetchers (`mocks/fetchers.ts`)
- Static mock data stored in JSON (`mock-data/calendar.mock.json`)
- Ready for API integration when backend is available

### 6. Task Data Normalization
The `fetchTasks` function includes defensive data normalization to ensure consistent property names:
```typescript
isCompleted: (task.isCompleted ?? task.completed ?? false) as boolean
```
This handles:
- Correct source data with `isCompleted`
- Legacy source data with `completed`
- Missing data defaults to `false`

---

## Features Migrated

### Core Calendar Views
- [x] Month View with day grid and event display
- [x] Week View with hourly time grid
- [x] Day View with detailed time slots
- [x] Agenda View with upcoming events list

### Event Management
- [x] Create/Edit/Delete events via modal
- [x] Event popover for quick view
- [x] Drag-and-drop event rescheduling
- [x] All-day event support

### Advanced Features
- [x] Recurring events (daily/weekly/monthly)
- [x] Multi-timezone support with conversion
- [x] Natural language event parsing (NLP input)
- [x] AI-powered daily planning panel
- [x] AI consent flow
- [x] Video call integration (Zoom, Meet, Teams, Webex)
- [x] Travel time buffer visualization
- [x] Task-to-event conversion via drag-and-drop

### UI/UX
- [x] Collapsible sidebar with mini-calendar
- [x] Calendar color coding
- [x] Calendar visibility toggles
- [x] Animated view transitions
- [x] Current time indicator
- [x] Responsive design
- [x] Undo toast for deleted events (5-second window)
- [x] Enhanced drag overlay with visual feedback

---

## Integration Requirements

### 1. shadcn/ui Components
The following shadcn/ui components must be installed in the Capella Pro monorepo:

```bash
npx shadcn@latest add button input textarea label switch select
npx shadcn@latest add popover scroll-area separator badge
npx shadcn@latest add checkbox toggle-group command form
```

### 2. Path Aliases
Ensure `tsconfig.json` includes:
```json
{
  "compilerOptions": {
    "paths": {
      "@/*": ["./src/*"],
      "@/components/*": ["./components/*"],
      "@/lib/*": ["./lib/*"]
    }
  }
}
```

### 3. Required Dependencies
```json
{
  "@dnd-kit/core": "^6.x",
  "@dnd-kit/sortable": "^8.x",
  "@dnd-kit/utilities": "^3.x",
  "@tanstack/react-query": "^5.x",
  "framer-motion": "^10.x",
  "luxon": "^3.x",
  "react-hook-form": "^7.x",
  "@hookform/resolvers": "^3.x",
  "rrule": "^2.x",
  "zod": "^3.x",
  "zustand": "^4.x"
}
```

### 4. CSS/Tailwind Configuration
Ensure Tailwind CSS includes animation utilities:
```javascript
// tailwind.config.js
module.exports = {
  // ... existing config
  plugins: [
    require('tailwindcss-animate'),
  ],
}
```

---

## LSP Diagnostics Note

Current LSP diagnostics (~593) are expected and will resolve upon integration:
- Missing shadcn/ui component imports (`@/components/ui/*`)
- Missing utility function (`cn` from `@/lib/utils`)
- These are standard shadcn/ui patterns that will work once set up in the monorepo

---

## Testing Checklist

After integration, verify:

- [ ] Calendar loads without errors
- [ ] All four views (Month, Week, Day, Agenda) render correctly
- [ ] Events display with correct colors and times
- [ ] Drag-and-drop works for events
- [ ] Create event modal opens and saves events
- [ ] Edit/Delete event functionality works
- [ ] NLP input parses natural language correctly
- [ ] Recurring events expand properly
- [ ] Timezone conversion displays correctly
- [ ] AI Planning panel opens with consent flow
- [ ] Sidebar calendar navigation works
- [ ] Tasks can be dragged to calendar

---

## Directory Structure

```
apps/web/app/calendar/
├── page.tsx                     # Route entry point
├── layout.tsx                   # Metadata layout
├── calendar_migration_audit.md  # This document
├── components/
│   ├── index.ts                 # Component exports
│   ├── CalendarPage.tsx         # Main page component
│   ├── CalendarHeader.tsx       # Header with navigation
│   ├── CalendarSidebar.tsx      # Sidebar with mini calendar
│   ├── SidebarCalendarsList.tsx # Calendar/task visibility toggles
│   ├── MiniCalendar.tsx         # Small calendar widget
│   ├── MonthView.tsx            # Month grid view
│   ├── WeekView.tsx             # Week time grid view
│   ├── DayView.tsx              # Day time grid view
│   ├── AgendaView.tsx           # List view of events
│   ├── EventPill.tsx            # Event display component
│   ├── CreateEventModal.tsx     # Event create/edit modal
│   ├── EventPopover.tsx         # Event quick view
│   ├── NLPInput.tsx             # Natural language input
│   ├── RecurringEventOptions.tsx # Recurrence settings
│   ├── TimezoneSelector.tsx     # Timezone picker
│   ├── VideoCallPicker.tsx      # Video call integration
│   ├── TravelTimeField.tsx      # Travel time settings
│   ├── AIPlannerPanel.tsx       # AI suggestions panel
│   ├── AIConsentModal.tsx       # AI consent dialog
│   ├── DragLayer.tsx            # Drag overlay with visual feedback
│   └── UndoToast.tsx            # Undo toast for deleted events
├── hooks/
│   ├── index.ts                 # Hook exports
│   ├── useCalendarData.ts       # Data fetching hook
│   ├── useNLPInput.ts           # NLP parsing hook
│   ├── useDragEvents.ts         # Drag-and-drop hook
│   ├── useDailyPlanner.ts       # AI planning hook
│   └── useRecurrence.ts         # Recurrence logic hook
├── lib/
│   ├── dateUtils.ts             # Date utilities
│   └── recurrence.ts            # rrule.js wrapper
├── store/
│   └── calendarStore.ts         # Zustand store (with undo stack)
├── types/
│   └── calendar.types.ts        # TypeScript types
├── mocks/
│   └── fetchers.ts              # Mock API fetchers
└── mock-data/
    └── calendar.mock.json       # Sample calendar data
```

---

## Migration Complete

All 21 components, 6 hooks, 2 library utilities, 1 store (with undo functionality), and mock data have been successfully migrated to the Next.js App Router structure. The calendar is ready for integration into the Capella Pro monorepo once shadcn/ui components are installed.
