"use client";

import { DateTime, Interval } from 'luxon';
import type { CalendarEvent } from '../types/calendar.types';

export function getMonthDays(date: DateTime): DateTime[] {
  const start = date.startOf('month').startOf('week');
  const end = date.endOf('month').endOf('week');
  
  const days: DateTime[] = [];
  let current = start;
  
  while (current <= end) {
    days.push(current);
    current = current.plus({ days: 1 });
  }
  
  return days;
}

export function getWeekDays(date: DateTime): DateTime[] {
  const start = date.startOf('week');
  return Array.from({ length: 7 }, (_, i) => start.plus({ days: i }));
}

export function isToday(date: DateTime): boolean {
  return date.hasSame(DateTime.now(), 'day');
}

export function isCurrentMonth(date: DateTime, currentDate: DateTime): boolean {
  return date.hasSame(currentDate, 'month');
}

export function isWeekend(date: DateTime): boolean {
  return date.weekday === 6 || date.weekday === 7;
}

export function formatDateRange(start: DateTime, end: DateTime): string {
  if (start.hasSame(end, 'day')) {
    return `${start.toFormat('EEEE, MMMM d')} · ${start.toFormat('h:mm a')} - ${end.toFormat('h:mm a')}`;
  }
  return `${start.toFormat('MMM d, h:mm a')} - ${end.toFormat('MMM d, h:mm a')}`;
}

export function parseEventDateTime(event: CalendarEvent): { start: DateTime; end: DateTime } {
  return {
    start: DateTime.fromISO(event.startTime, { zone: event.timezone }),
    end: DateTime.fromISO(event.endTime, { zone: event.timezone }),
  };
}

export function convertToUserTimezone(date: DateTime, userTimezone: string): DateTime {
  return date.setZone(userTimezone);
}

export function isDifferentTimezone(eventTimezone: string, userTimezone: string): boolean {
  const now = DateTime.now();
  const eventOffset = now.setZone(eventTimezone).offset;
  const userOffset = now.setZone(userTimezone).offset;
  return eventOffset !== userOffset;
}

export function formatTimezoneOffset(timezone: string): string {
  const offset = DateTime.now().setZone(timezone).toFormat('ZZZZ');
  return `${timezone.split('/').pop()?.replace(/_/g, ' ')} (${offset})`;
}

export function getEventsForDate(
  events: CalendarEvent[],
  date: DateTime,
  userTimezone: string
): CalendarEvent[] {
  return events.filter((event) => {
    const { start, end } = parseEventDateTime(event);
    const localStart = convertToUserTimezone(start, userTimezone);
    const localEnd = convertToUserTimezone(end, userTimezone);
    
    if (event.isAllDay) {
      return localStart.hasSame(date, 'day');
    }
    
    const dayStart = date.startOf('day');
    const dayEnd = date.endOf('day');
    
    return (
      (localStart >= dayStart && localStart <= dayEnd) ||
      (localEnd >= dayStart && localEnd <= dayEnd) ||
      (localStart <= dayStart && localEnd >= dayEnd)
    );
  });
}

export function getEventsForWeek(
  events: CalendarEvent[],
  weekStart: DateTime,
  userTimezone: string
): CalendarEvent[] {
  const weekEnd = weekStart.plus({ days: 6 }).endOf('day');
  
  return events.filter((event) => {
    const { start, end } = parseEventDateTime(event);
    const localStart = convertToUserTimezone(start, userTimezone);
    const localEnd = convertToUserTimezone(end, userTimezone);
    
    return (
      (localStart >= weekStart && localStart <= weekEnd) ||
      (localEnd >= weekStart && localEnd <= weekEnd) ||
      (localStart <= weekStart && localEnd >= weekEnd)
    );
  });
}

export function getEventPositionInDay(
  event: CalendarEvent,
  userTimezone: string,
  hourHeight: number
): { top: number; height: number } {
  const { start, end } = parseEventDateTime(event);
  const localStart = convertToUserTimezone(start, userTimezone);
  const localEnd = convertToUserTimezone(end, userTimezone);
  
  const startMinutes = localStart.hour * 60 + localStart.minute;
  const endMinutes = localEnd.hour * 60 + localEnd.minute;
  const durationMinutes = endMinutes - startMinutes;
  
  const top = (startMinutes / 60) * hourHeight;
  const height = (durationMinutes / 60) * hourHeight;
  
  return { top, height };
}

export function getEventPositionInWeek(
  event: CalendarEvent,
  weekStart: DateTime,
  userTimezone: string,
  hourHeight: number,
  dayWidth: number
): { top: number; left: number; width: number; height: number; dayIndex: number } {
  const { start, end } = parseEventDateTime(event);
  const localStart = convertToUserTimezone(start, userTimezone);
  const localEnd = convertToUserTimezone(end, userTimezone);
  
  const dayIndex = Math.floor(localStart.diff(weekStart.startOf('day'), 'days').days);
  const startMinutes = localStart.hour * 60 + localStart.minute;
  const endMinutes = localEnd.hour * 60 + localEnd.minute;
  const durationMinutes = endMinutes - startMinutes;
  
  const top = (startMinutes / 60) * hourHeight;
  const height = (durationMinutes / 60) * hourHeight;
  const left = dayIndex * dayWidth;
  
  return { top, left, width: dayWidth, height, dayIndex };
}

export function getTimeSlots(interval: number = 60): { hour: number; label: string }[] {
  const slots: { hour: number; label: string }[] = [];
  for (let hour = 0; hour < 24; hour++) {
    const time = DateTime.now().set({ hour, minute: 0 });
    slots.push({
      hour,
      label: time.toFormat('h a'),
    });
  }
  return slots;
}

export function snapToGrid(date: DateTime, gridMinutes: number): DateTime {
  const minutes = date.minute;
  const snapped = Math.round(minutes / gridMinutes) * gridMinutes;
  return date.set({ minute: snapped, second: 0, millisecond: 0 });
}

export function getRelativeDateLabel(date: DateTime): string {
  const now = DateTime.now();
  const diffDays = Math.floor(date.diff(now.startOf('day'), 'days').days);
  
  if (diffDays === 0) return 'Today';
  if (diffDays === 1) return 'Tomorrow';
  if (diffDays === -1) return 'Yesterday';
  if (diffDays > 1 && diffDays <= 7) return date.toFormat('EEEE');
  return date.toFormat('MMMM d');
}

export function calculateTravelBuffer(event: CalendarEvent): { bufferStart: { hour: number; minute: number } } | null {
  if (!event.travelTime || !event.location) return null;
  
  const { start } = parseEventDateTime(event);
  const bufferStart = start.minus({ minutes: event.travelTime.minutes });
  
  return {
    bufferStart: {
      hour: bufferStart.hour,
      minute: bufferStart.minute,
    },
  };
}

export function getOverlappingEvents(
  events: CalendarEvent[],
  userTimezone: string
): Map<string, { column: number; totalColumns: number }> {
  const positions = new Map<string, { column: number; totalColumns: number }>();
  
  if (events.length === 0) return positions;
  
  const sortedEvents = [...events].sort((a, b) => {
    const aStart = DateTime.fromISO(a.startTime);
    const bStart = DateTime.fromISO(b.startTime);
    return aStart.toMillis() - bStart.toMillis();
  });
  
  const columns: CalendarEvent[][] = [];
  
  for (const event of sortedEvents) {
    const { start, end } = parseEventDateTime(event);
    const localStart = convertToUserTimezone(start, userTimezone);
    const localEnd = convertToUserTimezone(end, userTimezone);
    
    let placed = false;
    
    for (let col = 0; col < columns.length; col++) {
      const column = columns[col];
      const lastEvent = column[column.length - 1];
      const { end: lastEnd } = parseEventDateTime(lastEvent);
      const lastEndLocal = convertToUserTimezone(lastEnd, userTimezone);
      
      if (localStart >= lastEndLocal) {
        column.push(event);
        positions.set(event.id, { column: col, totalColumns: columns.length });
        placed = true;
        break;
      }
    }
    
    if (!placed) {
      columns.push([event]);
      positions.set(event.id, { column: columns.length - 1, totalColumns: columns.length });
    }
  }
  
  const totalColumns = columns.length;
  positions.forEach((pos, id) => {
    positions.set(id, { ...pos, totalColumns });
  });
  
  return positions;
}
