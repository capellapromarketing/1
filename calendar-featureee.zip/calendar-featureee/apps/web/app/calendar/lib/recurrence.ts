"use client";

import { RRule, Frequency } from 'rrule';
import { DateTime } from 'luxon';
import type { CalendarEvent, RecurrenceRule, RecurrenceFrequency } from '../types/calendar.types';

const frequencyMap: Record<RecurrenceFrequency, Frequency> = {
  daily: RRule.DAILY,
  weekly: RRule.WEEKLY,
  monthly: RRule.MONTHLY,
};

export function createRRule(recurrence: RecurrenceRule, startDate: DateTime): RRule {
  const options: Partial<ConstructorParameters<typeof RRule>[0]> = {
    freq: frequencyMap[recurrence.frequency],
    interval: recurrence.interval,
    dtstart: startDate.toJSDate(),
  };

  if (recurrence.until) {
    options.until = DateTime.fromISO(recurrence.until).toJSDate();
  }

  if (recurrence.count) {
    options.count = recurrence.count;
  }

  if (recurrence.byDay && recurrence.byDay.length > 0) {
    options.byweekday = recurrence.byDay;
  }

  return new RRule(options);
}

export function expandRecurringEvent(
  event: CalendarEvent,
  rangeStart: DateTime,
  rangeEnd: DateTime
): CalendarEvent[] {
  if (!event.recurrence) {
    return [event];
  }

  const { start, end } = {
    start: DateTime.fromISO(event.startTime, { zone: event.timezone }),
    end: DateTime.fromISO(event.endTime, { zone: event.timezone }),
  };
  
  const duration = end.diff(start);
  const rule = createRRule(event.recurrence, start);
  
  const occurrences = rule.between(
    rangeStart.toJSDate(),
    rangeEnd.toJSDate(),
    true
  );

  return occurrences.map((occurrence, index) => {
    const occurrenceStart = DateTime.fromJSDate(occurrence);
    const occurrenceEnd = occurrenceStart.plus(duration);

    return {
      ...event,
      id: `${event.id}-occurrence-${index}`,
      startTime: occurrenceStart.toISO() || event.startTime,
      endTime: occurrenceEnd.toISO() || event.endTime,
      recurrenceId: event.id,
    };
  });
}

export function expandAllRecurringEvents(
  events: CalendarEvent[],
  rangeStart: DateTime,
  rangeEnd: DateTime
): CalendarEvent[] {
  const expandedEvents: CalendarEvent[] = [];

  for (const event of events) {
    if (event.recurrence) {
      expandedEvents.push(...expandRecurringEvent(event, rangeStart, rangeEnd));
    } else {
      expandedEvents.push(event);
    }
  }

  return expandedEvents;
}

export function getRecurrenceDescription(recurrence: RecurrenceRule): string {
  const { frequency, interval } = recurrence;
  
  if (interval === 1) {
    switch (frequency) {
      case 'daily':
        return 'Daily';
      case 'weekly':
        if (recurrence.byDay && recurrence.byDay.length > 0) {
          const days = recurrence.byDay.map(d => getDayName(d)).join(', ');
          return `Weekly on ${days}`;
        }
        return 'Weekly';
      case 'monthly':
        return 'Monthly';
    }
  }

  const unit = frequency === 'daily' ? 'day' : frequency === 'weekly' ? 'week' : 'month';
  return `Every ${interval} ${unit}s`;
}

function getDayName(dayIndex: number): string {
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  return days[dayIndex] || '';
}

export function isRecurringEvent(event: CalendarEvent): boolean {
  return !!event.recurrence || !!event.recurrenceId;
}

export function getNextOccurrence(
  event: CalendarEvent,
  afterDate: DateTime
): DateTime | null {
  if (!event.recurrence) return null;

  const start = DateTime.fromISO(event.startTime, { zone: event.timezone });
  const rule = createRRule(event.recurrence, start);
  
  const next = rule.after(afterDate.toJSDate());
  return next ? DateTime.fromJSDate(next) : null;
}

export function updateSingleOccurrence(
  originalEvent: CalendarEvent,
  occurrenceDate: DateTime,
  updates: Partial<CalendarEvent>
): CalendarEvent {
  return {
    ...originalEvent,
    ...updates,
    id: `${originalEvent.id}-exception-${occurrenceDate.toISODate()}`,
    recurrence: undefined,
    recurrenceId: originalEvent.id,
    isRecurrenceException: true,
  };
}

export function updateThisAndFollowing(
  originalEvent: CalendarEvent,
  fromDate: DateTime,
  updates: Partial<CalendarEvent>
): { updatedOriginal: CalendarEvent; newSeries: CalendarEvent } {
  const updatedOriginal: CalendarEvent = {
    ...originalEvent,
    recurrence: originalEvent.recurrence
      ? {
          ...originalEvent.recurrence,
          until: fromDate.minus({ days: 1 }).toISO() || undefined,
        }
      : undefined,
  };

  const newSeries: CalendarEvent = {
    ...originalEvent,
    ...updates,
    id: `${originalEvent.id}-series-${fromDate.toISODate()}`,
    startTime: fromDate.toISO() || originalEvent.startTime,
  };

  return { updatedOriginal, newSeries };
}
